# 詳細インストールガイド

## 📋 システム要件

### 必要なソフトウェア
- **Node.js**: v18.0.0以上
- **PostgreSQL**: v13.0以上
- **Git**: v2.0以上
- **OpenAI API キー**: 有料アカウントが必要

### 推奨環境
- **OS**: Ubuntu 20.04 LTS / Windows 10 / macOS 12+
- **RAM**: 4GB以上
- **ストレージ**: 2GB以上の空き容量

## 🚀 ステップバイステップ インストール

### Step 1: 基本ソフトウェアのインストール

#### Ubuntu/Debian
```bash
# システムの更新
sudo apt update && sudo apt upgrade -y

# Node.jsのインストール
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# PostgreSQLのインストール
sudo apt install -y postgresql postgresql-contrib

# Gitのインストール
sudo apt install -y git
```

#### Windows
1. [Node.js公式サイト](https://nodejs.org/)からLTSバージョンをダウンロード
2. [PostgreSQL公式サイト](https://www.postgresql.org/download/windows/)からインストーラーをダウンロード
3. [Git公式サイト](https://git-scm.com/)からGit for Windowsをダウンロード

#### macOS
```bash
# Homebrewを使用
brew install node
brew install postgresql
brew install git

# PostgreSQLサービスの開始
brew services start postgresql
```

### Step 2: PostgreSQLの設定

#### データベースの作成
```bash
# PostgreSQLサービスの開始（Linux）
sudo systemctl start postgresql
sudo systemctl enable postgresql

# PostgreSQLユーザーでログイン
sudo -u postgres psql

# データベースとユーザーの作成
CREATE DATABASE invoice_db;
CREATE USER invoice_user WITH PASSWORD 'secure_password123';
GRANT ALL PRIVILEGES ON DATABASE invoice_db TO invoice_user;
ALTER USER invoice_user CREATEDB;
\q
```

#### 接続テスト
```bash
# 作成したユーザーでログインテスト
psql -U invoice_user -d invoice_db -h localhost
```

### Step 3: プロジェクトの取得と設定

#### リポジトリのクローン
```bash
# プロジェクトのクローン
git clone https://github.com/yourusername/electronic-invoice-management.git
cd electronic-invoice-management

# 依存関係のインストール
npm install
```

#### 環境変数の設定
```bash
# .envファイルの作成
cp .env.example .env

# エディタで.envファイルを編集
nano .env
```

**.envファイルの設定例:**
```env
# データベース接続
DATABASE_URL=postgresql://invoice_user:secure_password123@localhost:5432/invoice_db

# OpenAI API Key
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxx

# PostgreSQL接続情報
PGHOST=localhost
PGPORT=5432
PGUSER=invoice_user
PGPASSWORD=secure_password123
PGDATABASE=invoice_db

# アプリケーション設定
NODE_ENV=development
PORT=5000

# セキュリティ設定
SESSION_SECRET=your_very_long_random_session_secret_here

# ファイル設定
MAX_FILE_SIZE=10485760
UPLOAD_DIR=uploads
```

### Step 4: OpenAI APIキーの取得

#### 1. OpenAIアカウントの作成
1. [OpenAI Platform](https://platform.openai.com/)にアクセス
2. 「Sign up」をクリックしてアカウントを作成
3. メールアドレスの確認を完了

#### 2. 支払い方法の設定
1. [Billing Settings](https://platform.openai.com/account/billing/overview)に移動
2. 「Set up paid account」をクリック
3. クレジットカード情報を入力
4. 月額利用制限を設定（推奨：$10-20）

#### 3. APIキーの生成
1. [API Keys](https://platform.openai.com/api-keys)ページに移動
2. 「Create new secret key」をクリック
3. 名前を設定（例：「Invoice Management System」）
4. 生成されたキーをコピー
5. .envファイルに貼り付け

### Step 5: データベースの初期化

```bash
# データベーススキーマの作成
npm run db:push

# テーブルが作成されたことを確認
psql -U invoice_user -d invoice_db -c "\dt"
```

### Step 6: アプリケーションの起動

```bash
# 開発モードで起動
npm run dev

# 正常に起動したかを確認
curl http://localhost:5000/api/health
```

## 🔧 トラブルシューティング

### 一般的な問題と解決方法

#### 1. Node.jsのバージョンエラー
```bash
# Node.jsのバージョンを確認
node --version

# 古いバージョンの場合、最新版をインストール
# Ubuntu/Debian
sudo apt remove nodejs npm
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs
```

#### 2. PostgreSQL接続エラー
```bash
# PostgreSQLサービスの状態確認
sudo systemctl status postgresql

# サービスの再起動
sudo systemctl restart postgresql

# 接続設定の確認
sudo -u postgres psql -c "SELECT version();"
```

#### 3. 権限エラー
```bash
# uploadsディレクトリの作成と権限設定
mkdir -p uploads
chmod 755 uploads

# ログディレクトリの作成
mkdir -p logs
chmod 755 logs
```

#### 4. OpenAI APIエラー
- APIキーが正しく設定されているか確認
- 使用量制限に達していないか確認
- 支払い方法が有効であることを確認

### 詳細なログの確認
```bash
# アプリケーションログの確認
npm run dev 2>&1 | tee app.log

# データベースログの確認
sudo tail -f /var/log/postgresql/postgresql-*.log
```

## 🚀 本番環境への展開

### 1. 環境変数の設定
```bash
# 本番用環境変数
NODE_ENV=production
PORT=5000
DATABASE_URL=postgresql://user:password@localhost:5432/invoice_db
```

### 2. プロセス管理
```bash
# PM2を使用したプロセス管理
npm install -g pm2

# アプリケーションの起動
pm2 start npm --name "invoice-system" -- start

# 自動起動の設定
pm2 startup
pm2 save
```

### 3. Nginx設定（オプション）
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📊 性能最適化

### 1. データベースの最適化
```sql
-- インデックスの作成
CREATE INDEX idx_invoice_date ON invoice_documents(invoice_date);
CREATE INDEX idx_company_name ON invoice_documents(company_name);
CREATE INDEX idx_invoice_number ON invoice_documents(invoice_number);
```

### 2. ファイル管理
```bash
# 定期的なファイル清理（cron設定）
# 30日以上古いファイルを削除
find uploads -name "*.pdf" -mtime +30 -delete
```

## 🔄 アップデート手順

### 1. 定期的なアップデート
```bash
# 最新コードの取得
git pull origin main

# 依存関係の更新
npm install

# データベーススキーマの更新
npm run db:push

# アプリケーションの再起動
pm2 restart invoice-system
```

### 2. バックアップの作成
```bash
# データベースのバックアップ
pg_dump -U invoice_user -d invoice_db > backup_$(date +%Y%m%d).sql

# アップロードファイルのバックアップ
tar -czf uploads_backup_$(date +%Y%m%d).tar.gz uploads/
```

## 📞 サポート

問題が発生した場合：
1. ログファイルを確認
2. 環境変数の設定を確認
3. データベース接続を確認
4. GitHub Issuesで質問を投稿

---

**注意**: 本番環境では必ずHTTPSを使用し、適切なセキュリティ対策を実施してください。