# Invoice Document Management System

## Overview

This is a full-stack invoice document management system built with React (frontend) and Express.js (backend). The application allows users to upload PDF invoices, store them securely with compliance features, and manage them through a modern web interface. The system includes features for document search, audit trails, and legal compliance checking.

## User Preferences

Preferred communication style: Simple, everyday language.
Deployment preference: Local deployment for security reasons (not cloud deployment).
Local setup: Windows environment with network server storage.
Server path: Network storage for production deployment

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation
- **File Upload**: React Dropzone for drag-and-drop file uploads

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM (DatabaseStorage implementation)
- **File Storage**: Local filesystem with hash-based integrity checking
- **File Upload**: Multer middleware for handling multipart/form-data
- **API Design**: RESTful endpoints with JSON responses
- **Error Handling**: Centralized error handling middleware
- **Database Connection**: Neon serverless PostgreSQL with connection pooling

## Key Components

### Database Schema
- **Invoice Documents Table**: Stores document metadata including filename, invoice details, file paths, hash values, and compliance status
- **Fields**: id, filename, originalName, invoiceNumber, companyName, invoiceDate, fileSize, mimeType, filePath, hashValue, timestamp, isCompliant, metadata, uploadedAt

### Core Features
1. **Document Upload**: PDF-only file upload with metadata extraction
2. **Document Search**: Filter by invoice number, company name, and date
3. **Document Viewing**: Modal-based document preview and details
4. **Compliance Checking**: Automatic integrity verification using hash values
5. **Audit Trail**: Timestamp tracking and metadata preservation

### UI Components
- **FileUpload**: Drag-and-drop interface with progress tracking
- **SearchFilter**: Multi-field search with real-time filtering
- **DocumentList**: Paginated table view with sorting capabilities
- **DocumentModal**: Detailed document view with compliance status
- **ComplianceStatus**: Visual indicators for legal compliance

## Data Flow

1. **Upload Process**:
   - User selects PDF file via drag-and-drop or file picker
   - File is validated (PDF only, 10MB max)
   - Metadata is extracted and stored alongside file
   - Hash value is generated for integrity checking
   - Document is saved to filesystem and database

2. **Search Process**:
   - User enters search criteria in filter form
   - Query is sent to backend with pagination parameters
   - Results are filtered and returned with total count
   - Frontend displays paginated results with sorting options

3. **Document Management**:
   - Users can view document details in modal overlay
   - Compliance status is checked against stored hash values
   - Audit reports can be generated for legal compliance

## External Dependencies

### Frontend Dependencies
- **UI Framework**: React, React DOM
- **Styling**: Tailwind CSS, Radix UI primitives
- **State Management**: TanStack Query
- **Form Handling**: React Hook Form, Zod validation
- **File Upload**: React Dropzone
- **Date Handling**: date-fns
- **Routing**: Wouter

### Backend Dependencies
- **Server**: Express.js
- **Database**: Drizzle ORM, @neondatabase/serverless
- **File Upload**: Multer
- **Session Management**: connect-pg-simple
- **Validation**: Zod with drizzle-zod integration

### Development Dependencies
- **Build Tools**: Vite, esbuild
- **TypeScript**: Full TypeScript support across stack
- **Database Tools**: Drizzle Kit for migrations
- **Development**: tsx for TypeScript execution

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds optimized static assets to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations are applied via `db:push` command

### Production Setup
- **Database**: PostgreSQL (configured for Neon serverless with connection pooling)
- **File Storage**: Local filesystem with uploads directory
- **Environment Variables**: DATABASE_URL, PGPORT, PGUSER, PGPASSWORD, PGDATABASE, PGHOST
- **Static Assets**: Served by Express in production mode
- **Database Schema**: Managed by Drizzle ORM with automatic migrations

### Development Workflow
- **Dev Server**: Vite dev server with HMR for frontend development
- **Backend**: tsx for running TypeScript server with hot reload
- **Database**: PostgreSQL with Drizzle ORM and real-time schema synchronization
- **Type Safety**: Shared schema types between frontend and backend
- **Database Management**: `npm run db:push` for schema migrations

## Recent Changes (2025-01-11)
- **Database Migration**: Successfully migrated from in-memory storage to PostgreSQL database
- **Storage Implementation**: Replaced MemStorage with DatabaseStorage using Drizzle ORM
- **Schema Synchronization**: Configured automatic database schema management
- **Environment Setup**: Added PostgreSQL connection with full environment variable support
- **Type Safety**: Fixed all TypeScript compilation errors for database operations
- **Search Functionality**: Fixed search API errors and implemented advanced search with filters
- **UI Improvements**: Added navigation between upload/management and search screens
- **File Download**: Fixed Japanese filename encoding issues for proper file downloads
- **PDF Processing**: Removed PDF preview functionality per user request
- **Enhanced Search Interface**: Added dropdown selection for invoice issuers using database company names
- **Classification Management**: Implemented document classification system with categories (経費、仕入、売上、その他)
- **Audit Trail System**: Added comprehensive audit reporting with integrity verification and compliance checking
- **SelectItem Error Fix**: Resolved validation errors by replacing empty strings with proper default values
- **API Enhancements**: Added classification update and audit report generation endpoints
- **Complete Navigation System**: Fixed all sidebar navigation links and implemented full page routing
- **Page Implementation**: Created comprehensive pages for categories, audit, and settings
- **Legal Compliance Documentation**: Created comprehensive legal compliance documentation with proof of 電帳法 adherence
- **Information Pages**: Added "このアプリについて" (About) and "使い方" (How to Use) pages with detailed explanations
- **Production Ready**: All features tested and working, ready for deployment
- **UI/UX Fixes**: Resolved table display issues with proper column sizing and scrolling
- **Navigation System**: Fixed sidebar navigation across all pages with unified layout component
- **Social Media Ready**: Created comprehensive X (Twitter) posting materials for system promotion
- **GitHub Ready**: Removed all proprietary information and created comprehensive documentation for open-source sharing
- **Comprehensive Documentation**: Added detailed installation guide, FAQ, and security policy for complete user support

## Deployment Status
The application is now production-ready with:
- ✅ Complete CRUD operations for invoice documents
- ✅ Advanced search and filtering capabilities
- ✅ Document classification management with visual statistics
- ✅ Comprehensive audit trail system with individual and bulk reporting
- ✅ Full compliance with Japanese Electronic Record Keeping Act (電子帳簿保存法)
- ✅ Secure file storage with hash-based integrity verification
- ✅ Professional UI with responsive design
- ✅ All navigation and routing working correctly
- ✅ PostgreSQL database with proper schema management
- ✅ Error handling and user feedback systems
- ✅ Legal compliance documentation and proof of 電帳法 adherence
- ✅ Comprehensive user documentation with "About" and "How to Use" pages
- ✅ Menu navigation with information pages for user guidance

The system successfully handles PDF document upload, metadata extraction using OpenAI Vision API, document classification, search functionality, and audit trail generation, maintaining full compliance with electronic bookkeeping preservation laws. The application now includes comprehensive documentation explaining legal compliance and detailed usage instructions for end users.