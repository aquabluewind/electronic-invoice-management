import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import InvoiceManagement from "@/pages/invoice-management";
import DocumentSearch from "@/pages/document-search";
import Categories from "@/pages/categories";
import Audit from "@/pages/audit";
import Settings from "@/pages/settings";
import About from "@/pages/about";
import HowToUse from "@/pages/how-to-use";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={InvoiceManagement} />
        <Route path="/search" component={DocumentSearch} />
        <Route path="/categories" component={Categories} />
        <Route path="/audit" component={Audit} />
        <Route path="/settings" component={Settings} />
        <Route path="/about" component={About} />
        <Route path="/how-to-use" component={HowToUse} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
