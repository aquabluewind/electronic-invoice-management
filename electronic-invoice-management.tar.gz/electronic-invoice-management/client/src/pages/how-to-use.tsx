import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Upload, Search, Folder, Shield, FileText, AlertCircle, CheckCircle } from "lucide-react";

export default function HowToUse() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            使い方ガイド
          </h1>
          <p className="text-gray-600 text-lg">
            電子帳簿保存システムの基本的な使い方をステップごとに説明します
          </p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-blue-600" />
              1. 文書のアップロード
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">ファイルアップロードページにアクセス</h3>
                  <p className="text-sm text-gray-600">メニューの「ファイルアップロード」をクリックします</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">PDFファイルを選択</h3>
                  <p className="text-sm text-gray-600">ドラッグ&ドロップまたはクリックしてPDFファイルを選択します</p>
                  <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded">
                    <p className="text-xs text-yellow-700">
                      <AlertCircle className="inline w-3 h-3 mr-1" />
                      対応形式：PDF（最大10MB）
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">AI解析の実行</h3>
                  <p className="text-sm text-gray-600">アップロード後、AIが自動的に文書を解析し、請求書情報を抽出します</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Badge variant="outline">請求書番号</Badge>
                    <Badge variant="outline">発行者名</Badge>
                    <Badge variant="outline">請求日</Badge>
                    <Badge variant="outline">金額</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-green-600" />
              2. 文書の検索・閲覧
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">検索・閲覧ページにアクセス</h3>
                  <p className="text-sm text-gray-600">メニューの「検索・閲覧」をクリックします</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">検索条件の設定</h3>
                  <p className="text-sm text-gray-600">以下の条件で検索できます：</p>
                  <ul className="text-sm text-gray-600 mt-1 ml-4 space-y-1">
                    <li>• 請求書番号</li>
                    <li>• 発行者名（プルダウン選択）</li>
                    <li>• 請求日（日付範囲）</li>
                    <li>• 準拠状況（準拠/非準拠）</li>
                  </ul>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">文書の詳細表示</h3>
                  <p className="text-sm text-gray-600">検索結果の文書をクリックすると詳細情報を表示します</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Folder className="h-5 w-5 text-purple-600" />
              3. 分類管理
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">分類管理ページにアクセス</h3>
                  <p className="text-sm text-gray-600">メニューの「分類管理」をクリックします</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">文書の分類設定</h3>
                  <p className="text-sm text-gray-600">文書を以下のカテゴリに分類できます：</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Badge variant="outline" className="text-red-600 border-red-600">経費</Badge>
                    <Badge variant="outline" className="text-blue-600 border-blue-600">仕入</Badge>
                    <Badge variant="outline" className="text-green-600 border-green-600">売上</Badge>
                    <Badge variant="outline" className="text-gray-600 border-gray-600">その他</Badge>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-purple-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-purple-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">統計情報の確認</h3>
                  <p className="text-sm text-gray-600">カテゴリごとの文書数と準拠状況を確認できます</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-orange-600" />
              4. 監査証跡
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-orange-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold">1</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">監査証跡ページにアクセス</h3>
                  <p className="text-sm text-gray-600">メニューの「監査証跡」をクリックします</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-orange-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">監査レポートの生成</h3>
                  <p className="text-sm text-gray-600">個別文書または全体の監査レポートを生成できます</p>
                  <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded">
                    <p className="text-xs text-blue-700">
                      <CheckCircle className="inline w-3 h-3 mr-1" />
                      完全性チェック、改ざん検知、準拠状況確認を自動実行
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-orange-100 rounded-full p-1 mt-1">
                  <div className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">税務調査対応</h3>
                  <p className="text-sm text-gray-600">監査レポートは税務調査時の証拠資料として使用できます</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-red-600" />
              重要な注意事項
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <h3 className="font-semibold text-red-800 mb-2">電子帳簿保存法への準拠</h3>
                <ul className="text-sm text-red-700 space-y-1">
                  <li>• アップロードされた文書は自動的にハッシュ値が生成され、改ざん検知が可能です</li>
                  <li>• タイムスタンプが自動付与され、法的要件を満たします</li>
                  <li>• 文書の訂正・削除履歴は全て記録されます</li>
                  <li>• 検索機能により、税務調査時の迅速な対応が可能です</li>
                </ul>
              </div>
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h3 className="font-semibold text-yellow-800 mb-2">運用上の注意点</h3>
                <ul className="text-sm text-yellow-700 space-y-1">
                  <li>• PDFファイルのみ対応しています（最大10MB）</li>
                  <li>• アップロード後は元の文書を適切に管理してください</li>
                  <li>• 定期的に監査証跡を確認し、システムの健全性を維持してください</li>
                  <li>• 重要な文書は複数のバックアップを取ることを推奨します</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>よくある質問</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-1">Q: 個人開発のシステムでも法的に有効ですか？</h3>
                <p className="text-sm text-gray-600">A: はい。2022年の法改正により事前承認制度が廃止され、技術的要件を満たせば開発者の属性は問わないとされています。</p>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Q: 税務調査時にはどのような対応が必要ですか？</h3>
                <p className="text-sm text-gray-600">A: 監査証跡機能により、電子データと監査レポートを提供できます。また、必要に応じて書面での出力も可能です。</p>
              </div>
              <div>
                <h3 className="font-semibold mb-1">Q: 文書の保存期間はどのくらいですか？</h3>
                <p className="text-sm text-gray-600">A: 法人は7年間、個人は5年間の保存が義務付けられています。システムでは永続保存が可能です。</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 p-4 bg-gray-100 rounded-lg">
          <div className="text-center">
            <p className="text-sm text-gray-600">
              サポートが必要な場合は、システム管理者にお問い合わせください。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}