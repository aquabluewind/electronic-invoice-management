import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon, 
  Building2,
  Shield,
  Database,
  Bell,
  Download,
  Upload
} from "lucide-react";
import { toast } from "@/hooks/use-toast";

export default function Settings() {
  const [companyName, setCompanyName] = useState("オオツカビジュアル株式会社");
  const [maxFileSize, setMaxFileSize] = useState("10");
  const [autoClassify, setAutoClassify] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(false);
  const [auditLogRetention, setAuditLogRetention] = useState("7");

  const handleSave = () => {
    toast({
      title: "設定を保存しました",
      description: "システム設定が正常に更新されました",
    });
  };

  const handleExportSettings = () => {
    const settings = {
      companyName,
      maxFileSize,
      autoClassify,
      emailNotifications,
      auditLogRetention,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(settings, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'system-settings.json';
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
    
    toast({
      title: "設定をエクスポートしました",
      description: "設定ファイルをダウンロードしました",
    });
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">システム設定</h1>
          <p className="text-gray-600">請求書管理システムの設定</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExportSettings} variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            設定エクスポート
          </Button>
          <Button onClick={handleSave} className="gap-2">
            <SettingsIcon className="h-4 w-4" />
            設定保存
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Company Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              会社情報
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="company-name">会社名</Label>
              <Input
                id="company-name"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="会社名を入力"
              />
            </div>
            
            <div>
              <Label htmlFor="max-file-size">最大ファイルサイズ (MB)</Label>
              <Input
                id="max-file-size"
                type="number"
                value={maxFileSize}
                onChange={(e) => setMaxFileSize(e.target.value)}
                placeholder="10"
              />
            </div>
          </CardContent>
        </Card>

        {/* Security Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              セキュリティ設定
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>自動分類機能</Label>
                <p className="text-sm text-gray-600">
                  アップロード時に自動で文書を分類
                </p>
              </div>
              <Switch
                checked={autoClassify}
                onCheckedChange={setAutoClassify}
              />
            </div>
            
            <Separator />
            
            <div>
              <Label htmlFor="audit-retention">監査ログ保持期間 (年)</Label>
              <Input
                id="audit-retention"
                type="number"
                value={auditLogRetention}
                onChange={(e) => setAuditLogRetention(e.target.value)}
                placeholder="7"
              />
            </div>
          </CardContent>
        </Card>

        {/* System Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              システム情報
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-medium text-gray-500">バージョン</Label>
                <p className="text-sm font-mono">v1.0.0</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">データベース</Label>
                <p className="text-sm font-mono">PostgreSQL</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">ストレージ</Label>
                <p className="text-sm font-mono">ローカルファイル</p>
              </div>
              <div>
                <Label className="text-sm font-medium text-gray-500">環境</Label>
                <p className="text-sm font-mono">Development</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notification Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              通知設定
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>メール通知</Label>
                <p className="text-sm text-gray-600">
                  アップロード完了時にメール通知
                </p>
              </div>
              <Switch
                checked={emailNotifications}
                onCheckedChange={setEmailNotifications}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label className="text-sm font-medium">法的要件</Label>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>電子帳簿保存法準拠</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>タイムスタンプ機能</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>改ざん防止機能</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-green-600" />
                  <span>監査証跡機能</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}