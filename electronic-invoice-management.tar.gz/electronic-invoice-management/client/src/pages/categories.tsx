import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Tag, 
  FileText,
  Building2,
  Calendar,
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import type { InvoiceDocument } from "@shared/schema";

const categoryIcons = {
  "経費": TrendingDown,
  "仕入": Package,
  "売上": TrendingUp,
  "その他": DollarSign,
  "未分類": FileText
};

const categoryColors = {
  "経費": "bg-red-100 text-red-800",
  "仕入": "bg-blue-100 text-blue-800", 
  "売上": "bg-green-100 text-green-800",
  "その他": "bg-yellow-100 text-yellow-800",
  "未分類": "bg-gray-100 text-gray-800"
};

export default function Categories() {
  const queryClient = useQueryClient();

  // Fetch all documents to analyze categories
  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/documents');
      return response.json();
    },
  });

  // Classification mutation
  const classificationMutation = useMutation({
    mutationFn: async ({ documentId, classification }: { documentId: number; classification: string }) => {
      const response = await apiRequest('PUT', `/api/documents/${documentId}/classify`, { classification });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "分類完了",
        description: "文書の分類を更新しました",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
    },
    onError: (error) => {
      toast({
        title: "分類エラー",
        description: error instanceof Error ? error.message : "分類に失敗しました",
        variant: "destructive",
      });
    },
  });

  // Categorize documents
  const categorizedDocuments = documents.reduce((acc: Record<string, InvoiceDocument[]>, doc: InvoiceDocument) => {
    const metadata = doc.metadata ? JSON.parse(doc.metadata) : {};
    const category = metadata.classification || "未分類";
    if (!acc[category]) acc[category] = [];
    acc[category].push(doc);
    return acc;
  }, {});

  const handleClassification = (documentId: number, classification: string) => {
    classificationMutation.mutate({ documentId, classification: classification === "none" ? "" : classification });
  };

  const categoryStats = Object.entries(categorizedDocuments).map(([category, docs]) => ({
    category,
    count: docs.length,
    percentage: Math.round((docs.length / documents.length) * 100) || 0
  }));

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">分類管理</h1>
          <p className="text-gray-600">請求書文書の分類状況と管理</p>
        </div>
      </div>

      {/* Category Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {categoryStats.map(({ category, count, percentage }) => {
          const Icon = categoryIcons[category as keyof typeof categoryIcons] || FileText;
          return (
            <Card key={category}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="h-5 w-5 text-gray-600" />
                    <span className="font-medium">{category}</span>
                  </div>
                  <Badge className={categoryColors[category as keyof typeof categoryColors]}>
                    {count}件
                  </Badge>
                </div>
                <div className="mt-2 text-sm text-gray-500">
                  全体の{percentage}%
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Document Classification Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Tag className="h-5 w-5" />
            文書分類一覧
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : documents.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600">文書がありません</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ファイル名</TableHead>
                    <TableHead>請求書番号</TableHead>
                    <TableHead>請求元</TableHead>
                    <TableHead>請求日</TableHead>
                    <TableHead>現在の分類</TableHead>
                    <TableHead>分類変更</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documents.map((document: InvoiceDocument) => {
                    const metadata = document.metadata ? JSON.parse(document.metadata) : {};
                    const currentCategory = metadata.classification || "未分類";
                    
                    return (
                      <TableRow key={document.id}>
                        <TableCell className="font-medium">
                          {document.originalName}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className="text-sm text-gray-600">{document.invoiceNumber || "未設定"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Building2 className="h-4 w-4 text-gray-400" />
                            <span className="text-sm">{document.companyName || "未設定"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-400" />
                            <span className="text-sm">{document.invoiceDate || "未設定"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={categoryColors[currentCategory as keyof typeof categoryColors]}>
                            {currentCategory}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={currentCategory === "未分類" ? "none" : currentCategory}
                            onValueChange={(value) => handleClassification(document.id, value)}
                            disabled={classificationMutation.isPending}
                          >
                            <SelectTrigger className="w-32">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="none">未分類</SelectItem>
                              <SelectItem value="経費">経費</SelectItem>
                              <SelectItem value="仕入">仕入</SelectItem>
                              <SelectItem value="売上">売上</SelectItem>
                              <SelectItem value="その他">その他</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}