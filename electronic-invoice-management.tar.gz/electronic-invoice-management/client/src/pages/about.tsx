import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { CheckCircle, Shield, FileText, Database, Clock, Search } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            電子帳簿保存システムについて
          </h1>
          <p className="text-gray-600 text-lg">
            電子帳簿保存法完全準拠の次世代型文書管理システム
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-600" />
                法的準拠性
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">電子帳簿保存法完全準拠</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">2022年改正法対応済み</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">税務署認可不要</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="text-sm">重加算税リスク回避</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-blue-600" />
                主要機能
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">PDF文書の自動アップロード</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">AI OCR文書解析</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">高度な検索・分類機能</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">監査証跡の自動生成</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5 text-purple-600" />
              技術的要件への準拠
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold mb-3 text-gray-900">真実性の確保</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">ハッシュ値による改ざん検知</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">タイムスタンプ機能</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">訂正・削除履歴の保存</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-3 text-gray-900">可視性の確保</h3>
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">日付・金額・取引先検索</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">範囲検索対応</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-green-600 border-green-600">実装済み</Badge>
                    <span className="text-sm">画面表示・印刷機能</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-orange-600" />
              重要な法的変更点
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <h3 className="font-semibold text-yellow-800 mb-2">2022年改正のポイント</h3>
              <div className="space-y-2 text-sm text-yellow-700">
                <p>• <strong>事前承認制度の廃止</strong>：税務署への申請が不要になりました</p>
                <p>• <strong>個人開発システムの認可</strong>：技術的要件を満たせば開発者の属性は問わない</p>
                <p>• <strong>電子取引データ保存の義務化</strong>：2024年1月より完全義務化</p>
                <p>• <strong>猶予措置の提供</strong>：相当の理由がある場合の猶予措置</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-indigo-600" />
              システムの特徴
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600 mb-1">セキュア</div>
                <div className="text-sm text-blue-700">
                  ローカルネットワーク内での安全な文書管理
                </div>
              </div>
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600 mb-1">高速</div>
                <div className="text-sm text-green-700">
                  AI技術による高速文書解析と検索
                </div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-2xl font-bold text-purple-600 mb-1">準拠</div>
                <div className="text-sm text-purple-700">
                  電子帳簿保存法完全準拠で安心運用
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 p-4 bg-gray-100 rounded-lg">
          <div className="text-center">
            <p className="text-sm text-gray-600">
              開発者：aquablue | 
              プロジェクト：電子帳簿保存システム | 
              準拠法令：電子帳簿保存法（平成10年法律第25号）| 
              最終更新：2025年1月
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}