import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

import { DocumentModal } from "@/components/document-modal";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Search, 
  Filter, 
  Download, 
  Eye,
  FileText,
  Calendar,
  Building2,
  Hash,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  FileBarChart,
  Tag,
  Trash2
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import type { InvoiceDocument } from "@shared/schema";

interface SearchFilters {
  invoiceNumber?: string;
  companyName?: string;
  invoiceDate?: string;
  dateRange?: string;
  complianceStatus?: string;
}

export default function DocumentSearch() {
  const [filters, setFilters] = useState<SearchFilters>({});
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedDateRange, setSelectedDateRange] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("uploadedAt");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");
  const [selectedDocument, setSelectedDocument] = useState<InvoiceDocument | null>(null);
  const itemsPerPage = 20;

  const queryClient = useQueryClient();

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      queryClient.invalidateQueries({ queryKey: ['/api/documents/search'] });
      toast({
        title: "削除完了",
        description: "文書が削除されました",
      });
    },
    onError: (error: any) => {
      toast({
        title: "削除エラー",
        description: error.message || "文書の削除に失敗しました",
        variant: "destructive",
      });
    }
  });

  // Fetch unique company names for dropdown
  const { data: companyNames = [] } = useQuery({
    queryKey: ['/api/companies'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/companies');
      return response.json();
    },
  });

  // Fetch documents with search filters
  const { data: searchResults, isLoading, refetch } = useQuery({
    queryKey: ['/api/documents/search', filters, currentPage, sortBy, sortOrder],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (filters.invoiceNumber) params.append('invoiceNumber', filters.invoiceNumber);
      if (filters.companyName) params.append('companyName', filters.companyName);
      if (filters.invoiceDate) params.append('invoiceDate', filters.invoiceDate);
      if (filters.complianceStatus) params.append('complianceStatus', filters.complianceStatus);
      
      params.append('page', currentPage.toString());
      params.append('limit', itemsPerPage.toString());
      params.append('sortBy', sortBy);
      params.append('sortOrder', sortOrder);
      
      const response = await apiRequest('GET', `/api/documents/search?${params.toString()}`);
      return response.json();
    },
  });

  // Download mutation
  const downloadMutation = useMutation({
    mutationFn: async (documentId: number) => {
      const response = await fetch(`/api/documents/${documentId}/download`);
      if (!response.ok) throw new Error('ダウンロードに失敗しました');
      return response.blob();
    },
    onSuccess: (blob, documentId) => {
      // Find document name
      const document = searchResults?.documents?.find((d: InvoiceDocument) => d.id === documentId);
      const filename = document?.originalName || 'document.pdf';
      
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "ダウンロード完了",
        description: `${filename} をダウンロードしました`,
      });
    },
    onError: (error) => {
      toast({
        title: "ダウンロードエラー",
        description: error instanceof Error ? error.message : "ダウンロードに失敗しました",
        variant: "destructive",
      });
    },
  });

  // Classification mutation
  const classificationMutation = useMutation({
    mutationFn: async ({ documentId, classification }: { documentId: number; classification: string }) => {
      const response = await apiRequest('PUT', `/api/documents/${documentId}/classify`, { classification });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "分類完了",
        description: "文書の分類を更新しました",
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "分類エラー",
        description: error instanceof Error ? error.message : "分類に失敗しました",
        variant: "destructive",
      });
    },
  });

  const handleSearch = () => {
    setCurrentPage(1);
    refetch();
  };

  const handleClear = () => {
    setFilters({});
    setSelectedDateRange("");
    setCurrentPage(1);
    refetch();
  };

  const handleDateRangeChange = (range: string) => {
    setSelectedDateRange(range);
    const today = new Date();
    let startDate = "";
    
    switch (range) {
      case "today":
        startDate = today.toISOString().split('T')[0];
        break;
      case "week":
        const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
        startDate = weekAgo.toISOString().split('T')[0];
        break;
      case "month":
        const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);
        startDate = monthAgo.toISOString().split('T')[0];
        break;
      case "year":
        const yearAgo = new Date(today.getTime() - 365 * 24 * 60 * 60 * 1000);
        startDate = yearAgo.toISOString().split('T')[0];
        break;
    }
    
    if (startDate) {
      setFilters({ ...filters, invoiceDate: startDate });
    }
  };

  const handleAuditReport = async (documentId: number) => {
    try {
      const response = await apiRequest('GET', `/api/documents/${documentId}/audit`);
      const auditData = await response.json();
      
      const auditReport = `監査証跡レポート
===================
文書ID: ${auditData.documentId}
ファイル名: ${auditData.filename}
請求書番号: ${auditData.invoiceNumber}
請求元: ${auditData.companyName}
アップロード日時: ${auditData.uploadTimestamp}
元ハッシュ値: ${auditData.originalHash}
現在ハッシュ値: ${auditData.currentHash}
整合性: ${auditData.integrityValid ? '正常' : '異常'}
コンプライアンス: ${auditData.complianceStatus}
生成日時: ${auditData.generatedAt}

法的要件チェック:
- タイムスタンプ準拠: ${auditData.legalRequirements.timestampCompliance ? '✓' : '✗'}
- 改ざん防止: ${auditData.legalRequirements.tamperPrevention ? '✓' : '✗'}
- メタデータ保持: ${auditData.legalRequirements.metadataRetention ? '✓' : '✗'}
- 電子保存: ${auditData.legalRequirements.electronicPreservation ? '✓' : '✗'}
`;
      
      const blob = new Blob([auditReport], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-report-${documentId}.txt`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "監査証跡生成完了",
        description: "監査証跡レポートをダウンロードしました",
      });
    } catch (error) {
      console.error("Audit report error:", error);
      toast({
        title: "監査証跡エラー",
        description: error instanceof Error ? error.message : "監査証跡の生成に失敗しました",
        variant: "destructive",
      });
    }
  };

  const handleClassification = (documentId: number, classification: string) => {
    classificationMutation.mutate({ documentId, classification });
  };

  const totalPages = Math.ceil((searchResults?.total || 0) / itemsPerPage);
  const documents = searchResults?.documents || [];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">文書検索・管理</h1>
          <p className="text-gray-600">保存された請求書の検索・閲覧・分類管理</p>
        </div>
        <Button onClick={handleClear} variant="outline" className="gap-2">
          <RefreshCw className="h-4 w-4" />
          リセット
        </Button>
      </div>

      {/* Search Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            検索フィルター
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="search-invoice-number" className="flex items-center gap-2">
                <Hash className="h-4 w-4" />
                請求書番号
              </Label>
              <Input
                id="search-invoice-number"
                value={filters.invoiceNumber || ""}
                onChange={(e) => setFilters({ ...filters, invoiceNumber: e.target.value })}
                placeholder="例: INV-2024-001"
              />
            </div>
            
            <div>
              <Label className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                請求元
              </Label>
              <Select 
                value={filters.companyName || "all"} 
                onValueChange={(value) => setFilters({ ...filters, companyName: value === "all" ? undefined : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="請求元を選択" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">すべての請求元</SelectItem>
                  {companyNames.map((company: string) => (
                    <SelectItem key={company} value={company}>
                      {company}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                期間
              </Label>
              <Select value={selectedDateRange} onValueChange={handleDateRangeChange}>
                <SelectTrigger>
                  <SelectValue placeholder="期間を選択" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">今日</SelectItem>
                  <SelectItem value="week">1週間以内</SelectItem>
                  <SelectItem value="month">1ヶ月以内</SelectItem>
                  <SelectItem value="year">1年以内</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label>コンプライアンス状況</Label>
              <Select 
                value={filters.complianceStatus || "all"} 
                onValueChange={(value) => setFilters({ ...filters, complianceStatus: value === "all" ? undefined : value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="すべて" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">すべて</SelectItem>
                  <SelectItem value="compliant">準拠</SelectItem>
                  <SelectItem value="non-compliant">要確認</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={handleSearch} className="gap-2">
              <Search className="h-4 w-4" />
              検索
            </Button>
            <Button onClick={handleClear} variant="outline">
              クリア
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              検索結果
            </CardTitle>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Label>並び順:</Label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="uploadedAt">アップロード日</SelectItem>
                    <SelectItem value="invoiceDate">請求日</SelectItem>
                    <SelectItem value="companyName">請求元</SelectItem>
                    <SelectItem value="invoiceNumber">請求書番号</SelectItem>
                  </SelectContent>
                </Select>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSortOrder(sortOrder === "asc" ? "desc" : "asc")}
                >
                  {sortOrder === "asc" ? "昇順" : "降順"}
                </Button>
              </div>
              <Badge variant="outline">
                {searchResults?.total || 0} 件中 {documents.length} 件表示
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : documents.length === 0 ? (
            <div className="text-center py-12">
              <Search className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600">検索条件に一致する文書がありません</p>
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ファイル名</TableHead>
                      <TableHead>請求書番号</TableHead>
                      <TableHead>請求元</TableHead>
                      <TableHead>請求日</TableHead>
                      <TableHead>アップロード日</TableHead>
                      <TableHead>コンプライアンス</TableHead>
                      <TableHead>操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {documents.map((document: InvoiceDocument) => (
                      <TableRow key={document.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-red-500" />
                            <span className="font-medium">{document.originalName}</span>
                          </div>
                        </TableCell>
                        <TableCell>{document.invoiceNumber || "—"}</TableCell>
                        <TableCell>{document.companyName || "—"}</TableCell>
                        <TableCell>{document.invoiceDate || "—"}</TableCell>
                        <TableCell>
                          {new Date(document.uploadedAt).toLocaleDateString('ja-JP')}
                        </TableCell>
                        <TableCell>
                          <Badge 
                            variant={document.isCompliant ? "default" : "secondary"}
                            className={document.isCompliant ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}
                          >
                            {document.isCompliant ? "準拠" : "要確認"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => downloadMutation.mutate(document.id)}
                              disabled={downloadMutation.isPending}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedDocument(document)}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleAuditReport(document.id)}
                            >
                              <FileBarChart className="h-4 w-4" />
                            </Button>
                            <Select
                              value={document.metadata ? JSON.parse(document.metadata)?.classification || "none" : "none"}
                              onValueChange={(value) => handleClassification(document.id, value === "none" ? "" : value)}
                            >
                              <SelectTrigger className="w-24 h-8">
                                <SelectValue placeholder="分類">
                                  <Tag className="h-4 w-4" />
                                </SelectValue>
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="none">未分類</SelectItem>
                                <SelectItem value="経費">経費</SelectItem>
                                <SelectItem value="仕入">仕入</SelectItem>
                                <SelectItem value="売上">売上</SelectItem>
                                <SelectItem value="その他">その他</SelectItem>
                              </SelectContent>
                            </Select>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                if (window.confirm('この文書を削除しますか？')) {
                                  deleteMutation.mutate(document.id);
                                }
                              }}
                              disabled={deleteMutation.isPending}
                              className="text-red-600 hover:text-red-800 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-gray-600">
                    {Math.min((currentPage - 1) * itemsPerPage + 1, searchResults?.total || 0)} - {Math.min(currentPage * itemsPerPage, searchResults?.total || 0)} 件目
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(currentPage - 1)}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <span className="text-sm">
                      {currentPage} / {totalPages}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(currentPage + 1)}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Document Modal */}
      {selectedDocument && (
        <DocumentModal
          document={selectedDocument}
          onClose={() => setSelectedDocument(null)}
        />
      )}
    </div>
  );
}