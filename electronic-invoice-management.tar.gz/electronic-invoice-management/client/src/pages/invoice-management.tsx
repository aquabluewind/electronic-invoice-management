import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileUpload } from "@/components/file-upload";
import { SearchFilter } from "@/components/search-filter";
import { DocumentList } from "@/components/document-list";
import { DocumentModal } from "@/components/document-modal";
import { ComplianceStatus } from "@/components/compliance-status";
import type { InvoiceDocument } from "@shared/schema";

interface SearchFilters {
  invoiceNumber?: string;
  companyName?: string;
  invoiceDate?: string;
}

export default function InvoiceManagement() {
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({});
  const [selectedDocument, setSelectedDocument] = useState<InvoiceDocument | null>(null);
  const [currentPage, setCurrentPage] = useState(1);

  const { data: documents = [], isLoading, refetch } = useQuery<InvoiceDocument[]>({
    queryKey: ['/api/documents'],
  });

  const handleSearch = (filters: SearchFilters) => {
    setSearchFilters(filters);
    setCurrentPage(1);
  };

  const handleDocumentClick = (document: InvoiceDocument) => {
    setSelectedDocument(document);
  };

  const handleUploadSuccess = () => {
    refetch();
  };

  return (
    <div className="space-y-6">
      {/* Status Overview */}
      <ComplianceStatus />
      
      {/* File Upload */}
      <FileUpload onUploadSuccess={handleUploadSuccess} />
      
      {/* Search Filter */}
      <SearchFilter onSearch={handleSearch} />
      
      {/* Document List */}
      <DocumentList
        documents={documents}
        isLoading={isLoading}
        onDocumentClick={handleDocumentClick}
      />

      {/* Document Modal */}
      {selectedDocument && (
        <DocumentModal
          document={selectedDocument}
          onClose={() => setSelectedDocument(null)}
        />
      )}
    </div>
  );
}
