import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Shield, 
  FileText,
  Download,
  CheckCircle,
  XCircle,
  AlertCircle,
  Calendar,
  Hash,
  Building2
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { toast } from "@/hooks/use-toast";
import type { InvoiceDocument } from "@shared/schema";

export default function Audit() {
  const [auditingDocuments, setAuditingDocuments] = useState<Set<number>>(new Set());

  // Fetch all documents
  const { data: documents = [], isLoading } = useQuery({
    queryKey: ['/api/documents'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/documents');
      return response.json();
    },
  });

  const handleAuditReport = async (documentId: number) => {
    try {
      setAuditingDocuments(prev => new Set(prev).add(documentId));
      
      const response = await apiRequest('GET', `/api/documents/${documentId}/audit`);
      const auditData = await response.json();
      
      const auditReport = `監査証跡レポート
===================
文書ID: ${auditData.documentId}
ファイル名: ${auditData.filename}
請求書番号: ${auditData.invoiceNumber}
請求元: ${auditData.companyName}
アップロード日時: ${auditData.uploadTimestamp}
元ハッシュ値: ${auditData.originalHash}
現在ハッシュ値: ${auditData.currentHash}
整合性: ${auditData.integrityValid ? '正常' : '異常'}
コンプライアンス: ${auditData.complianceStatus}
生成日時: ${auditData.generatedAt}

法的要件チェック:
- タイムスタンプ準拠: ${auditData.legalRequirements.timestampCompliance ? '✓' : '✗'}
- 改ざん防止: ${auditData.legalRequirements.tamperPrevention ? '✓' : '✗'}
- メタデータ保持: ${auditData.legalRequirements.metadataRetention ? '✓' : '✗'}
- 電子保存: ${auditData.legalRequirements.electronicPreservation ? '✓' : '✗'}
`;
      
      const blob = new Blob([auditReport], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit-report-${documentId}.txt`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "監査証跡生成完了",
        description: "監査証跡レポートをダウンロードしました",
      });
    } catch (error) {
      console.error("Audit report error:", error);
      toast({
        title: "監査証跡エラー",
        description: error instanceof Error ? error.message : "監査証跡の生成に失敗しました",
        variant: "destructive",
      });
    } finally {
      setAuditingDocuments(prev => {
        const newSet = new Set(prev);
        newSet.delete(documentId);
        return newSet;
      });
    }
  };

  const handleBulkAudit = async () => {
    try {
      const auditPromises = documents.map(async (doc: InvoiceDocument) => {
        const response = await apiRequest('GET', `/api/documents/${doc.id}/audit`);
        return response.json();
      });
      
      const auditResults = await Promise.all(auditPromises);
      
      const bulkReport = `一括監査証跡レポート
====================
生成日時: ${new Date().toISOString()}
対象文書数: ${documents.length}

${auditResults.map(auditData => `
文書ID: ${auditData.documentId}
ファイル名: ${auditData.filename}
請求書番号: ${auditData.invoiceNumber}
請求元: ${auditData.companyName}
整合性: ${auditData.integrityValid ? '正常' : '異常'}
コンプライアンス: ${auditData.complianceStatus}
---
`).join('')}

全体サマリー:
- 正常文書: ${auditResults.filter(r => r.integrityValid).length}件
- 異常文書: ${auditResults.filter(r => !r.integrityValid).length}件
- 準拠文書: ${auditResults.filter(r => r.complianceStatus === '準拠').length}件
`;
      
      const blob = new Blob([bulkReport], { type: 'text/plain;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `bulk-audit-report-${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "一括監査証跡生成完了",
        description: "全文書の監査証跡レポートをダウンロードしました",
      });
    } catch (error) {
      toast({
        title: "一括監査証跡エラー",
        description: error instanceof Error ? error.message : "一括監査証跡の生成に失敗しました",
        variant: "destructive",
      });
    }
  };

  // Calculate compliance statistics
  const totalDocuments = documents.length;
  const compliantDocuments = documents.filter((doc: InvoiceDocument) => doc.isCompliant).length;
  const complianceRate = totalDocuments > 0 ? Math.round((compliantDocuments / totalDocuments) * 100) : 0;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">監査証跡</h1>
          <p className="text-gray-600">文書の整合性チェックと監査証跡生成</p>
        </div>
        <Button onClick={handleBulkAudit} className="gap-2">
          <Download className="h-4 w-4" />
          一括監査証跡生成
        </Button>
      </div>

      {/* Compliance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-gray-600" />
                <span className="font-medium">総文書数</span>
              </div>
              <Badge variant="outline">{totalDocuments}件</Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium">準拠文書</span>
              </div>
              <Badge className="bg-green-100 text-green-800">{compliantDocuments}件</Badge>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-blue-600" />
                <span className="font-medium">準拠率</span>
              </div>
              <Badge className={complianceRate === 100 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}>
                {complianceRate}%
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Document Audit Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            文書監査状況
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : documents.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-600">文書がありません</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ファイル名</TableHead>
                    <TableHead>請求書番号</TableHead>
                    <TableHead>請求元</TableHead>
                    <TableHead>アップロード日時</TableHead>
                    <TableHead>コンプライアンス</TableHead>
                    <TableHead>整合性</TableHead>
                    <TableHead>監査証跡</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {documents.map((document: InvoiceDocument) => (
                    <TableRow key={document.id}>
                      <TableCell className="font-medium">
                        {document.originalName}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Hash className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{document.invoiceNumber || "未設定"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Building2 className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{document.companyName || "未設定"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">
                            {new Date(document.uploadedAt).toLocaleDateString('ja-JP')}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={document.isCompliant ? "default" : "destructive"}
                          className={
                            document.isCompliant
                              ? "bg-green-100 text-green-800"
                              : "bg-red-100 text-red-800"
                          }
                        >
                          {document.isCompliant ? (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          ) : (
                            <XCircle className="h-3 w-3 mr-1" />
                          )}
                          {document.isCompliant ? "準拠" : "要確認"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-600" />
                          <span className="text-sm text-green-700">正常</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleAuditReport(document.id)}
                          disabled={auditingDocuments.has(document.id)}
                          className="gap-2"
                        >
                          <Download className="h-4 w-4" />
                          {auditingDocuments.has(document.id) ? "生成中..." : "生成"}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}