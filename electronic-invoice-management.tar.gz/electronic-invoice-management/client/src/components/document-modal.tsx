import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { 
  FileText, 
  Download, 
  FileCheck, 
  X, 
  CheckCircle, 
  AlertTriangle, 
  Calendar, 
  Building, 
  Hash, 
  Clock,
  Edit,
  Save,
  RefreshCw
} from "lucide-react";
import type { InvoiceDocument } from "@shared/schema";

interface DocumentModalProps {
  document: InvoiceDocument;
  onClose: () => void;
}

interface AuditReport {
  documentId: number;
  filename: string;
  invoiceNumber: string;
  companyName: string;
  uploadTimestamp: string;
  originalHash: string;
  currentHash: string;
  integrityValid: boolean;
  complianceStatus: string;
  generatedAt: string;
  legalRequirements: {
    timestampCompliance: boolean;
    tamperPrevention: boolean;
    metadataRetention: boolean;
    electronicPreservation: boolean;
  };
}

export function DocumentModal({ document, onClose }: DocumentModalProps) {
  const [isOpen, setIsOpen] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [editedData, setEditedData] = useState({
    invoiceNumber: document.invoiceNumber || "",
    companyName: document.companyName || "",
    invoiceDate: document.invoiceDate || "",
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: auditReport, isLoading: auditLoading } = useQuery<AuditReport>({
    queryKey: ['/api/documents', document.id, 'audit'],
    enabled: isOpen,
  });

  const downloadMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch(`/api/documents/${document.id}/download`);
      if (!response.ok) throw new Error('Download failed');
      return response.blob();
    },
    onSuccess: (blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = document.originalName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({
        title: "ダウンロード完了",
        description: "ファイルをダウンロードしました。",
      });
    },
    onError: () => {
      toast({
        title: "ダウンロードエラー",
        description: "ファイルのダウンロードに失敗しました。",
        variant: "destructive",
      });
    },
  });

  const generateAuditReportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("GET", `/api/documents/${document.id}/audit`);
      return response.json();
    },
    onSuccess: (auditData) => {
      const auditJson = JSON.stringify(auditData, null, 2);
      const blob = new Blob([auditJson], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `audit_report_${document.id}.json`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({
        title: "監査レポート生成完了",
        description: "監査レポートをダウンロードしました。",
      });
    },
    onError: () => {
      toast({
        title: "監査レポート生成エラー",
        description: "監査レポートの生成に失敗しました。",
        variant: "destructive",
      });
    },
  });

  const updateDocumentMutation = useMutation({
    mutationFn: async (updates: Partial<InvoiceDocument>) => {
      const response = await apiRequest("PATCH", `/api/documents/${document.id}`, updates);
      return response.json();
    },
    onSuccess: (updatedDocument) => {
      toast({
        title: "更新完了",
        description: "文書情報が更新されました。",
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
    },
    onError: () => {
      toast({
        title: "更新エラー",
        description: "文書情報の更新に失敗しました。",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setIsOpen(false);
    onClose();
  };

  const handleSave = () => {
    updateDocumentMutation.mutate({
      invoiceNumber: editedData.invoiceNumber || null,
      companyName: editedData.companyName || null,
      invoiceDate: editedData.invoiceDate || null,
    });
  };

  const handleEdit = () => {
    setIsEditing(true);
    setEditedData({
      invoiceNumber: document.invoiceNumber || "",
      companyName: document.companyName || "",
      invoiceDate: document.invoiceDate || "",
    });
  };

  const formatDate = (dateString: string | Date) => {
    return new Date(dateString).toLocaleString('ja-JP', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>文書詳細</span>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClose}
              className="h-6 w-6 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* PDF Display Area */}
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="pt-6">
                <div className="bg-gray-100 rounded-lg p-8 h-96 flex items-center justify-center">
                  <div className="text-center">
                    <FileText className="h-16 w-16 text-red-500 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">PDF表示エリア</p>
                    <p className="text-sm text-gray-500">
                      実装時にPDFビューワーを統合
                    </p>
                    <Button 
                      variant="outline" 
                      className="mt-4"
                      onClick={() => downloadMutation.mutate()}
                      disabled={downloadMutation.isPending}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      PDFを開く
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Document Information */}
          <div className="lg:col-span-1 space-y-6">
            {/* Basic Information */}
            <Card>
              <CardContent className="pt-6">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  文書情報
                </h4>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-700">ファイル名</Label>
                    <p className="text-sm text-gray-900 break-words">{document.originalName}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700 flex items-center justify-between">
                      請求書番号
                      {!isEditing && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleEdit}
                          className="h-6 w-6 p-0"
                        >
                          <Edit className="h-3 w-3" />
                        </Button>
                      )}
                    </Label>
                    {isEditing ? (
                      <Input
                        value={editedData.invoiceNumber}
                        onChange={(e) => setEditedData({ ...editedData, invoiceNumber: e.target.value })}
                        placeholder="請求書番号を入力"
                        className="text-sm"
                      />
                    ) : (
                      <p className="text-sm text-gray-900">{document.invoiceNumber || "—"}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">請求元</Label>
                    {isEditing ? (
                      <Input
                        value={editedData.companyName}
                        onChange={(e) => setEditedData({ ...editedData, companyName: e.target.value })}
                        placeholder="請求元の会社名を入力"
                        className="text-sm"
                      />
                    ) : (
                      <p className="text-sm text-gray-900">{document.companyName || "—"}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">請求日</Label>
                    {isEditing ? (
                      <Input
                        type="date"
                        value={editedData.invoiceDate}
                        onChange={(e) => setEditedData({ ...editedData, invoiceDate: e.target.value })}
                        className="text-sm"
                      />
                    ) : (
                      <p className="text-sm text-gray-900">{document.invoiceDate || "—"}</p>
                    )}
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">ファイルサイズ</Label>
                    <p className="text-sm text-gray-900">{formatFileSize(document.fileSize)}</p>
                  </div>
                  
                  {isEditing && (
                    <div className="flex items-center space-x-2 pt-2">
                      <Button
                        size="sm"
                        onClick={handleSave}
                        disabled={updateDocumentMutation.isPending}
                        className="flex-1"
                      >
                        <Save className="mr-2 h-4 w-4" />
                        保存
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setIsEditing(false)}
                        className="flex-1"
                      >
                        キャンセル
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Compliance Information */}
            <Card>
              <CardContent className="pt-6">
                <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                  <CheckCircle className="mr-2 h-5 w-5 text-green-500" />
                  法的準拠情報
                </h4>
                <div className="space-y-3">
                  <div>
                    <Label className="text-sm font-medium text-gray-700 flex items-center">
                      <Clock className="mr-1 h-4 w-4" />
                      タイムスタンプ
                    </Label>
                    <p className="text-sm text-gray-900">{formatDate(document.timestamp)}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700 flex items-center">
                      <Hash className="mr-1 h-4 w-4" />
                      ハッシュ値
                    </Label>
                    <p className="text-xs text-gray-600 font-mono break-all">
                      {document.hashValue.substring(0, 32)}...
                    </p>
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700">準拠状況</Label>
                    <Badge 
                      variant={document.isCompliant ? "default" : "secondary"}
                      className={
                        document.isCompliant 
                          ? "bg-green-100 text-green-800 hover:bg-green-100" 
                          : "bg-yellow-100 text-yellow-800 hover:bg-yellow-100"
                      }
                    >
                      {document.isCompliant ? (
                        <CheckCircle className="w-3 h-3 mr-1" />
                      ) : (
                        <AlertTriangle className="w-3 h-3 mr-1" />
                      )}
                      {document.isCompliant ? "準拠" : "確認中"}
                    </Badge>
                  </div>
                  {auditReport && (
                    <div>
                      <Label className="text-sm font-medium text-gray-700">改ざん検証</Label>
                      <Badge 
                        variant={auditReport.integrityValid ? "default" : "destructive"}
                        className={
                          auditReport.integrityValid 
                            ? "bg-green-100 text-green-800 hover:bg-green-100" 
                            : "bg-red-100 text-red-800 hover:bg-red-100"
                        }
                      >
                        {auditReport.integrityValid ? "正常" : "改ざん検出"}
                      </Badge>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Legal Requirements */}
            {auditReport && (
              <Card>
                <CardContent className="pt-6">
                  <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                    <FileCheck className="mr-2 h-5 w-5" />
                    法的要件チェック
                  </h4>
                  <div className="space-y-2">
                    {Object.entries(auditReport.legalRequirements).map(([key, value]) => (
                      <div key={key} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          {key === 'timestampCompliance' && 'タイムスタンプ'}
                          {key === 'tamperPrevention' && '改ざん防止'}
                          {key === 'metadataRetention' && 'メタデータ保持'}
                          {key === 'electronicPreservation' && '電子保存'}
                        </span>
                        <Badge 
                          variant={value ? "default" : "destructive"}
                          className={
                            value 
                              ? "bg-green-100 text-green-800 hover:bg-green-100" 
                              : "bg-red-100 text-red-800 hover:bg-red-100"
                          }
                        >
                          {value ? "適合" : "不適合"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button
                onClick={() => downloadMutation.mutate()}
                disabled={downloadMutation.isPending}
                className="w-full"
              >
                <Download className="mr-2 h-4 w-4" />
                {downloadMutation.isPending ? "ダウンロード中..." : "ダウンロード"}
              </Button>
              <Button
                variant="outline"
                onClick={() => generateAuditReportMutation.mutate()}
                disabled={generateAuditReportMutation.isPending}
                className="w-full"
              >
                <FileCheck className="mr-2 h-4 w-4" />
                {generateAuditReportMutation.isPending ? "生成中..." : "監査レポート生成"}
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
