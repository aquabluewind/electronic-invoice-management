import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, Search, Folder, Shield, Settings } from "lucide-react";

export function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "ホーム", icon: Home },
    { path: "/search", label: "検索・管理", icon: Search },
    { path: "/categories", label: "分類管理", icon: Folder },
    { path: "/audit", label: "監査証跡", icon: Shield },
    { path: "/settings", label: "設定", icon: Settings },
  ];

  return (
    <Card className="mb-6">
      <CardContent className="p-4">
        <nav className="flex space-x-2">
          {navItems.map(({ path, label, icon: Icon }) => (
            <Link key={path} href={path}>
              <Button
                variant={location === path ? "default" : "ghost"}
                size="sm"
                className="flex items-center gap-2"
              >
                <Icon className="h-4 w-4" />
                {label}
              </Button>
            </Link>
          ))}
        </nav>
      </CardContent>
    </Card>
  );
}