import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
// Removed table components - using HTML table instead
import { 
  FileText, 
  Eye, 
  Download, 
  Info, 
  ArrowUpDown,
  CheckCircle,
  AlertTriangle,
  ChevronLeft,
  ChevronRight,
  Trash2
} from "lucide-react";
import type { InvoiceDocument } from "@shared/schema";

interface DocumentListProps {
  documents: InvoiceDocument[];
  isLoading: boolean;
  onDocumentClick: (document: InvoiceDocument) => void;
}

export function DocumentList({ documents, isLoading, onDocumentClick }: DocumentListProps) {
  const [sortField, setSortField] = useState<keyof InvoiceDocument>("uploadedAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  console.log("DocumentList rendered with documents:", documents.length);
  console.log("First document:", documents[0]);
  console.log("isLoading:", isLoading);

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest('DELETE', `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/documents'] });
      toast({
        title: "削除完了",
        description: "文書が削除されました",
      });
    },
    onError: (error: any) => {
      toast({
        title: "削除エラー",
        description: error.message || "文書の削除に失敗しました",
        variant: "destructive",
      });
    }
  });

  const handleSort = (field: keyof InvoiceDocument) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  const sortedDocuments = [...documents].sort((a, b) => {
    const aValue = a[sortField];
    const bValue = b[sortField];
    
    if (aValue == null && bValue == null) return 0;
    if (aValue == null) return 1;
    if (bValue == null) return -1;
    
    let comparison = 0;
    if (aValue < bValue) comparison = -1;
    if (aValue > bValue) comparison = 1;
    
    return sortDirection === "asc" ? comparison : -comparison;
  });

  const totalPages = Math.ceil(sortedDocuments.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedDocuments = sortedDocuments.slice(startIndex, endIndex);

  const handleDownload = async (document: InvoiceDocument, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const response = await fetch(`/api/documents/${document.id}/download`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = document.originalName;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Download error:', error);
    }
  };

  const handleDelete = async (document: InvoiceDocument, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`「${document.originalName}」を削除しますか？この操作は取り消せません。`)) {
      deleteMutation.mutate(document.id);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-gray-600">読み込み中...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-medium text-gray-900">保存済み請求書一覧</h2>
            <p className="text-sm text-gray-600">電子帳簿保存法準拠で保存された文書</p>
          </div>
          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
            {documents.length} 件
          </Badge>
        </div>

        {paginatedDocuments.length === 0 ? (
          <div className="text-center py-12">
            <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <p className="text-gray-600">保存された請求書がありません</p>
          </div>
        ) : (
          <>
            <div className="bg-white rounded-lg shadow overflow-x-auto border-2 border-gray-200" style={{ scrollbarWidth: 'thin', scrollbarColor: '#6b7280 #f3f4f6' }}>
              <table className="table-fixed w-full border-collapse" style={{ minWidth: '1000px' }}>
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '300px' }}>
                      ファイル名
                    </th>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '130px' }}>
                      請求書番号
                    </th>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '180px' }}>
                      請求元
                    </th>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '120px' }}>
                      日付
                    </th>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '80px' }}>
                      準拠
                    </th>
                    <th className="px-2 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b" style={{ width: '190px' }}>
                      操作
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white">
                  {paginatedDocuments.map((document) => (
                    <tr key={document.id} className="hover:bg-gray-50 border-b border-gray-200">
                      <td className="px-2 py-2" style={{ width: '300px' }}>
                        <div className="flex items-center">
                          <FileText className="h-4 w-4 text-red-500 mr-2 flex-shrink-0" />
                          <div className="text-xs font-medium text-gray-900 truncate">
                            {document.originalName}
                          </div>
                        </div>
                      </td>
                      <td className="px-2 py-2 text-xs text-gray-900 truncate" style={{ width: '130px' }}>
                        {document.invoiceNumber || "—"}
                      </td>
                      <td className="px-2 py-2 text-xs text-gray-900 truncate" style={{ width: '180px' }}>
                        {document.companyName || "—"}
                      </td>
                      <td className="px-2 py-2 text-xs text-gray-900 truncate" style={{ width: '120px' }}>
                        {document.invoiceDate || "—"}
                      </td>
                      <td className="px-2 py-2" style={{ width: '80px' }}>
                        <Badge 
                          variant={document.isCompliant ? "default" : "secondary"}
                          className={document.isCompliant ? "bg-green-100 text-green-800 text-xs px-1 py-0.5" : "bg-yellow-100 text-yellow-800 text-xs px-1 py-0.5"}
                        >
                          {document.isCompliant ? "準拠" : "確認中"}
                        </Badge>
                      </td>
                      <td className="px-2 py-2" style={{ width: '190px' }}>
                        <div className="flex items-center space-x-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              onDocumentClick(document);
                            }}
                            title="詳細を表示"
                            className="text-indigo-600 hover:text-indigo-900 p-1 h-6 w-6"
                          >
                            <Eye className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => handleDownload(document, e)}
                            title="ダウンロード"
                            className="text-blue-600 hover:text-blue-900 p-1 h-6 w-6"
                          >
                            <Download className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => handleDelete(document, e)}
                            disabled={deleteMutation.isPending}
                            className="text-red-600 hover:text-red-900 hover:bg-red-50 p-1 h-6 w-6"
                            title="削除"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            <div className="flex items-center justify-between mt-6">
              <div className="flex items-center">
                <span className="text-sm text-gray-700">
                  <span className="font-medium">{startIndex + 1}</span> - 
                  <span className="font-medium">{Math.min(endIndex, sortedDocuments.length)}</span> / 
                  <span className="font-medium">{sortedDocuments.length}</span> 件
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <span className="text-sm font-medium px-3 py-1 bg-primary text-white rounded-md">
                  {currentPage}
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
