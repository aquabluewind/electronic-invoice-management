import { CheckCircle } from "lucide-react";

const complianceItems = [
  { label: "タイムスタンプ", status: "正常" },
  { label: "改ざん防止", status: "正常" },
  { label: "メタデータ", status: "正常" },
];

export function ComplianceStatus() {
  return (
    <div className="mt-6 bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <h3 className="text-sm font-medium text-gray-900 mb-3">法的準拠状況</h3>
      <div className="space-y-3">
        {complianceItems.map((item) => (
          <div key={item.label} className="flex items-center justify-between">
            <span className="text-sm text-gray-600">{item.label}</span>
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
              <CheckCircle className="w-3 h-3 mr-1" />
              {item.status}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
