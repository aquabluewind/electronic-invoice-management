import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";

interface SearchFilters {
  invoiceNumber?: string;
  companyName?: string;
  invoiceDate?: string;
}

interface SearchFilterProps {
  onSearch: (filters: SearchFilters) => void;
}

export function SearchFilter({ onSearch }: SearchFilterProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    invoiceNumber: "",
    companyName: "",
    invoiceDate: "",
  });

  const handleSearch = () => {
    const nonEmptyFilters = Object.entries(filters).reduce((acc, [key, value]) => {
      if (value && value.trim()) {
        acc[key as keyof SearchFilters] = value.trim();
      }
      return acc;
    }, {} as SearchFilters);

    onSearch(nonEmptyFilters);
  };

  const handleClear = () => {
    setFilters({
      invoiceNumber: "",
      companyName: "",
      invoiceDate: "",
    });
    onSearch({});
  };

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">検索・フィルター</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <Label htmlFor="search-invoice-number">請求書番号</Label>
            <Input
              id="search-invoice-number"
              value={filters.invoiceNumber}
              onChange={(e) => setFilters({ ...filters, invoiceNumber: e.target.value })}
              placeholder="INV-2024-001"
            />
          </div>
          <div>
            <Label htmlFor="search-company-name">請求元</Label>
            <Input
              id="search-company-name"
              value={filters.companyName}
              onChange={(e) => setFilters({ ...filters, companyName: e.target.value })}
              placeholder="請求元の会社名で検索"
            />
          </div>
          <div>
            <Label htmlFor="search-date">期間</Label>
            <Input
              id="search-date"
              type="date"
              value={filters.invoiceDate}
              onChange={(e) => setFilters({ ...filters, invoiceDate: e.target.value })}
            />
          </div>
          <div className="flex items-end space-x-2">
            <Button onClick={handleSearch} className="flex-1">
              <Search className="mr-2 h-4 w-4" />
              検索
            </Button>
            <Button variant="outline" onClick={handleClear}>
              クリア
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
