import { Upload, Search, Folder, Shield, Settings, Info, HelpCircle } from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigationItems = [
  { icon: Upload, label: "ファイルアップロード", href: "/", path: "/" },
  { icon: Search, label: "検索・閲覧", href: "/search", path: "/search" },
  { icon: Folder, label: "分類管理", href: "/categories", path: "/categories" },
  { icon: Shield, label: "監査証跡", href: "/audit", path: "/audit" },
  { icon: Settings, label: "設定", href: "/settings", path: "/settings" },
  { icon: Info, label: "このアプリについて", href: "/about", path: "/about" },
  { icon: HelpCircle, label: "使い方", href: "/how-to-use", path: "/how-to-use" },
];

export function Sidebar() {
  const [location] = useLocation();
  
  return (
    <nav className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      <div className="space-y-2">
        {navigationItems.map((item) => (
          <Link
            key={item.label}
            href={item.href}
            className={cn(
              "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors",
              location === item.path
                ? "bg-primary text-white"
                : "text-gray-700 hover:bg-gray-100"
            )}
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
