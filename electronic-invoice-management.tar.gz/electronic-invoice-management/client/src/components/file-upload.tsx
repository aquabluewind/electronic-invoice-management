import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CloudUpload, Plus } from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface FileUploadProps {
  onUploadSuccess: () => void;
}

export function FileUpload({ onUploadSuccess }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [metadata, setMetadata] = useState({
    invoiceNumber: "",
    companyName: "",
    invoiceDate: "",
  });
  const { toast } = useToast();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("invoiceNumber", metadata.invoiceNumber);
      formData.append("companyName", metadata.companyName);
      formData.append("invoiceDate", metadata.invoiceDate);

      console.log("Uploading file:", file.name, "Size:", file.size, "Type:", file.type);
      console.log("Metadata:", metadata);

      const response = await fetch("/api/documents", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: "アップロードに失敗しました" }));
        throw new Error(errorData.message || "アップロードに失敗しました");
      }

      return response.json();
    },
    onSuccess: (data) => {
      let toastMessage = "ファイルが正常にアップロードされました。";
      
      if (data.extractedInfo && data.extractedInfo.isAutoExtracted) {
        toastMessage += "\n\n自動抽出された情報：";
        if (data.extractedInfo.invoiceNumber) toastMessage += `\n請求書番号: ${data.extractedInfo.invoiceNumber}`;
        if (data.extractedInfo.companyName) toastMessage += `\n請求元: ${data.extractedInfo.companyName}`;
        if (data.extractedInfo.invoiceDate) toastMessage += `\n請求日: ${data.extractedInfo.invoiceDate}`;
      } else if (data.extractedInfo && !data.extractedInfo.isAutoExtracted) {
        toastMessage += "\n\n自動抽出に失敗しました。必要に応じて手動で修正してください。";
      }
      
      toast({
        title: "アップロード完了",
        description: toastMessage,
      });
      setUploadProgress(0);
      setMetadata({ invoiceNumber: "", companyName: "", invoiceDate: "" });
      onUploadSuccess();
    },
    onError: (error) => {
      toast({
        title: "アップロードエラー",
        description: error instanceof Error ? error.message : "ファイルのアップロードに失敗しました。",
        variant: "destructive",
      });
      setUploadProgress(0);
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      if (file.type !== "application/pdf") {
        toast({
          title: "ファイル形式エラー",
          description: "PDFファイルのみアップロード可能です。",
          variant: "destructive",
        });
        return;
      }
      
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "ファイルサイズエラー",
          description: "ファイルサイズは10MB以下にしてください。",
          variant: "destructive",
        });
        return;
      }

      setUploadProgress(50);
      uploadMutation.mutate(file);
    }
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
    },
    maxFiles: 1,
  });

  return (
    <Card className="mb-6">
      <CardContent className="pt-6">
        <h2 className="text-lg font-medium text-gray-900 mb-4">PDFファイルアップロード</h2>
        <p className="text-sm text-gray-600 mb-4">
          PDFファイルをアップロードすると、AI技術により請求書情報を自動抽出します。<br />
          抽出できない場合は、手動で入力してください。
        </p>
        
        {/* Metadata inputs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <Label htmlFor="invoiceNumber">請求書番号（手動入力）</Label>
            <Input
              id="invoiceNumber"
              value={metadata.invoiceNumber}
              onChange={(e) => setMetadata({ ...metadata, invoiceNumber: e.target.value })}
              placeholder="INV-2024-001"
            />
          </div>
          <div>
            <Label htmlFor="companyName">請求元（手動入力）</Label>
            <Input
              id="companyName"
              value={metadata.companyName}
              onChange={(e) => setMetadata({ ...metadata, companyName: e.target.value })}
              placeholder="請求を行う会社名..."
            />
          </div>
          <div>
            <Label htmlFor="invoiceDate">請求日（手動入力）</Label>
            <Input
              id="invoiceDate"
              type="date"
              value={metadata.invoiceDate}
              onChange={(e) => setMetadata({ ...metadata, invoiceDate: e.target.value })}
            />
          </div>
        </div>

        {/* Upload area */}
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
            isDragActive
              ? "border-primary bg-primary/5"
              : "border-gray-300 hover:border-primary"
          }`}
        >
          <input {...getInputProps()} />
          <CloudUpload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-sm text-gray-600 mb-2">
            PDFファイルをドラッグ&ドロップするか、クリックしてファイルを選択
          </p>
          <p className="text-xs text-gray-500 mb-4">最大ファイルサイズ: 10MB</p>
          <Button
            type="button"
            variant="default"
            disabled={uploadMutation.isPending}
          >
            <Plus className="mr-2 h-4 w-4" />
            ファイルを選択
          </Button>
        </div>

        {/* Upload progress */}
        {uploadMutation.isPending && (
          <div className="mt-4">
            <Progress value={uploadProgress} className="h-2" />
            <p className="text-sm text-gray-600 mt-2">アップロード中... PDFから情報を抽出しています</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
