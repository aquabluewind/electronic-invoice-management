# 電子帳簿保存法対応 請求書管理システム

AI OCR技術を活用した次世代型電子帳簿管理システム。日本の電子帳簿保存法に完全準拠し、企業の文書管理を革新的に効率化します。

## 🚀 主な機能

### 📋 文書管理
- **AI OCR自動抽出**: OpenAI Vision APIによる請求書データの自動認識
- **スマート分類**: 経費・仕入・売上・その他への自動分類
- **高度検索**: 請求書番号・会社名・日付での絞り込み検索
- **ファイル管理**: セキュアな文書保存とダウンロード機能

### 🛡️ 法的準拠
- **電子帳簿保存法完全準拠**: 2025年改正法に対応
- **改ざん防止**: SHA-256ハッシュ値による完全性チェック
- **タイムスタンプ**: 法的要件を満たす時刻証明
- **監査証跡**: 包括的な監査レポート生成

### 📊 業務効率化
- **自動データ入力**: 手動入力作業を90%削減
- **リアルタイム処理**: アップロード即座にデータ抽出
- **統計ダッシュボード**: 分類別文書統計の可視化
- **レスポンシブUI**: デスクトップ・タブレット・スマートフォン対応

## 🛠️ 技術スタック

### Frontend
- **React 18** + **TypeScript** - モダンフロントエンド
- **Tailwind CSS** - ユーティリティファーストスタイリング
- **Radix UI** - アクセシブルなUIコンポーネント
- **TanStack Query** - 効率的なサーバーステート管理
- **Wouter** - 軽量ルーティング

### Backend
- **Node.js** + **Express** - サーバーサイドランタイム
- **PostgreSQL** - 信頼性の高いリレーショナルデータベース
- **Drizzle ORM** - 型安全なデータベースアクセス
- **Multer** - ファイルアップロード処理

### AI・外部サービス
- **OpenAI Vision API** - 文書内容の自動抽出
- **pdf2pic** - PDFから画像への変換
- **ImageMagick** - 画像処理

## 🏃‍♂️ クイックスタート

### 必要な環境
- Node.js 18+
- PostgreSQL 13+
- OpenAI API キー（各自で取得が必要）

### インストール

```bash
# リポジトリをクローン
git clone https://github.com/aquabluewind/electronic-invoice-management.git
cd electronic-invoice-management

# 依存関係をインストール
npm install

# 環境変数を設定
cp .env.example .env
# .envファイルを編集して必要な設定を追加

# データベースを設定
npm run db:push

# 開発サーバーを起動
npm run dev
```

### 環境変数の設定

```env
# データベース接続
DATABASE_URL=postgresql://username:password@localhost:5432/invoice_db

# OpenAI API Key (必須 - 各自で取得してください)
OPENAI_API_KEY=your_openai_api_key_here

# PostgreSQL接続情報
PGHOST=localhost
PGPORT=5432
PGUSER=username
PGPASSWORD=password
PGDATABASE=invoice_db
```

### 🔑 OpenAI API キーの取得方法

1. [OpenAI Platform](https://platform.openai.com/) にアクセス
2. アカウントを作成またはログイン
3. [API Keys](https://platform.openai.com/api-keys) ページへ移動
4. 「Create new secret key」をクリック
5. 生成されたキーを`.env`ファイルに設定

**重要**: 
- OpenAI APIは有料サービスです。利用前に料金体系をご確認ください
- APIキーは各自で取得・管理してください
- 環境変数として設定することで、キーの漏洩を防げます

## 📖 使い方

### 🚀 初回セットアップ

#### 1. 環境の確認
```bash
# Node.jsのバージョン確認
node --version  # v18以上であることを確認

# PostgreSQLの確認
psql --version  # 13以上であることを確認
```

#### 2. データベースの作成
```bash
# PostgreSQLにログイン
psql -U postgres

# データベースを作成
CREATE DATABASE invoice_db;

# ユーザーを作成（任意）
CREATE USER invoice_user WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE invoice_db TO invoice_user;
```

#### 3. OpenAI APIキーの取得
1. [OpenAI Platform](https://platform.openai.com/)でアカウント作成
2. 支払い方法を設定（クレジットカード等）
3. [API Keys](https://platform.openai.com/api-keys)でキーを生成
4. 使用量制限を設定（推奨：月額上限設定）

#### 4. 環境変数の設定例
```bash
# .envファイルの作成
cp .env.example .env

# 実際の値を設定
DATABASE_URL=postgresql://invoice_user:secure_password@localhost:5432/invoice_db
OPENAI_API_KEY=sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxx
```

### 💻 基本的な使い方

#### 1. 請求書のアップロード
**手順：**
1. メイン画面（請求書管理）にアクセス
2. 「ファイルを選択」をクリック、またはPDFファイルをドラッグ&ドロップ
3. ファイルサイズ制限：10MB以下
4. 対応形式：PDFのみ

**自動処理：**
- AI OCRが請求書内容を自動抽出
- 請求書番号、会社名、日付、金額を認識
- ハッシュ値を生成して改ざん防止
- データベースに保存

#### 2. 文書の分類管理
**分類カテゴリ：**
- 📊 **経費** - 一般的な経費
- 📦 **仕入** - 商品・材料の仕入
- 💰 **売上** - 売上に関する請求書
- 📋 **その他** - その他の文書

**分類の変更：**
1. 文書一覧で対象文書を選択
2. 詳細画面で分類を変更
3. 保存をクリック

#### 3. 高度な検索機能
**検索方法：**
- **基本検索**: 請求書番号・会社名で検索
- **日付検索**: 特定の期間で絞り込み
- **分類検索**: カテゴリ別で絞り込み
- **複合検索**: 複数条件の組み合わせ

**検索のコツ：**
- 部分一致検索が可能
- 日付は「YYYY-MM-DD」形式で入力
- 会社名は正式名称または略称で検索

#### 4. 監査レポートの活用
**監査の目的：**
- 電子帳簿保存法の要件確認
- ファイル改ざんの検知
- 法的証跡の確保

**レポート生成手順：**
1. 「監査」ページにアクセス
2. 対象期間を選択（月単位推奨）
3. 「監査レポート生成」をクリック
4. PDF形式でダウンロード

### 🔧 トラブルシューティング

#### よくある問題と解決方法

**1. ファイルアップロードに失敗する**
- ファイルサイズが10MB以下であることを確認
- PDFファイルが破損していないか確認
- ネットワーク接続を確認

**2. AI OCRが正しく認識しない**
- 画像が鮮明であることを確認
- 文字が読み取り可能であることを確認
- 手動で情報を修正

**3. データベース接続エラー**
```bash
# データベースサービスの確認
sudo systemctl status postgresql

# データベースの再起動
sudo systemctl restart postgresql
```

**4. OpenAI APIエラー**
- APIキーが正しく設定されているか確認
- 使用量制限に達していないか確認
- 支払い方法が有効であることを確認

### 📊 運用のベストプラクティス

#### 1. 定期的なメンテナンス
- **週次**: アップロードファイルの確認
- **月次**: 監査レポートの生成
- **四半期**: データベースのバックアップ

#### 2. セキュリティ対策
- 定期的なAPIキーの更新
- アクセスログの監視
- 不要なファイルの削除

#### 3. 効率的な運用
- 請求書の命名規則を統一
- 分類ルールの明確化
- 定期的な検索機能の活用

### 🎯 活用シーン

#### 中小企業の経理担当者
- 請求書の電子化とペーパーレス化
- 経費精算の効率化
- 税務調査対応の準備

#### 個人事業主
- 確定申告の書類整理
- 経費管理の自動化
- 法的要件の確実な遵守

#### 開発者・システム管理者
- 業務システムの参考実装
- AI OCR技術の学習
- 法的要件を満たすシステム設計の研究

## 🏗️ プロジェクト構成

```
electronic-invoice-system/
├── client/                 # フロントエンド
│   ├── src/
│   │   ├── components/     # UIコンポーネント
│   │   ├── pages/         # ページコンポーネント
│   │   ├── hooks/         # カスタムフック
│   │   └── lib/           # ユーティリティ
├── server/                 # バックエンド
│   ├── index.ts           # サーバーエントリーポイント
│   ├── routes.ts          # APIルート
│   ├── storage.ts         # データベース操作
│   └── pdf-analyzer.ts    # PDF解析処理
├── shared/                 # 共通型定義
│   └── schema.ts          # データベーススキーマ
└── uploads/               # アップロードファイル
```

## 🔧 開発

### 利用可能なスクリプト

```bash
# 開発サーバー起動
npm run dev

# プロダクションビルド
npm run build

# データベーススキーマ更新
npm run db:push

# 型チェック
npm run type-check
```

## 📚 詳細ドキュメント

- **[インストールガイド](INSTALLATION_GUIDE.md)** - 詳細なセットアップ手順
- **[FAQ](FAQ.md)** - よくある質問と回答
- **[セキュリティポリシー](SECURITY.md)** - セキュリティに関する重要な情報
- **[開発者・謝辞](CREDITS.md)** - 開発者情報と技術的な背景

### 開発ワークフロー

1. **機能開発**
   - `shared/schema.ts`でデータモデル定義
   - `server/storage.ts`でデータベース操作実装
   - `server/routes.ts`でAPI実装
   - `client/src/`でフロントエンド実装

2. **テスト**
   - 機能テスト：各画面での操作確認
   - APIテスト：Postmanやcurlでの動作確認
   - 法的要件テスト：監査レポートの生成確認

## 📋 法的準拠

### 電子帳簿保存法対応
- ✅ **真実性の要件**: SHA-256ハッシュによる改ざん検知
- ✅ **可視性の要件**: 高速検索とデータ表示
- ✅ **保存要件**: 適切なメタデータ保存
- ✅ **システム要件**: 操作ログとアクセス制御

### 監査対応
- 完全な操作履歴の記録
- ファイル完全性の検証
- 法的要件チェック機能
- 監査証跡レポート生成

## 🤝 貢献

1. フォークしてください
2. 機能ブランチを作成 (`git checkout -b feature/amazing-feature`)
3. 変更をコミット (`git commit -m 'Add amazing feature'`)
4. ブランチにプッシュ (`git push origin feature/amazing-feature`)
5. プルリクエストを作成してください

## 📄 ライセンス

このプロジェクトは MIT ライセンスの下で公開されています。詳細は [LICENSE](LICENSE) ファイルを参照してください。

## 👨‍💻 作成者

**aquablue**
- GitHub: [@aquabluewind](https://github.com/aquabluewind)
- プロジェクト: 電子帳簿保存法対応システムの設計・開発

## 🙏 謝辞

- OpenAI Vision API for document analysis
- React and TypeScript community
- All contributors and testers

## 📞 サポート

- 問題報告: GitHub Issues
- 機能要望: GitHub Discussions
- 技術的質問: GitHub Discussions

## ⚠️ 重要な注意事項

### API使用について
- OpenAI APIキーは各自で取得・管理してください
- APIの利用料金は各自の負担となります
- 本プロジェクトはAPIキーを提供しません

### 法的要件について
- このシステムは日本の電子帳簿保存法に準拠していますが、実際の運用前には法的要件を再確認してください
- 必要に応じて専門家にご相談ください

---

**免責事項**: 本システムは教育・研究目的のサンプルです。実際の業務利用前には十分な検証を行ってください。