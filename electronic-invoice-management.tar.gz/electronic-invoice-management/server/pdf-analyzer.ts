import OpenAI from "openai";
import fs from "fs";
import { fromPath } from "pdf2pic";
import { exec } from "child_process";
import { promisify } from "util";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const execAsync = promisify(exec);

export interface ExtractedInvoiceData {
  invoiceNumber?: string;
  companyName?: string;
  invoiceDate?: string;
  totalAmount?: string;
  isExtracted: boolean;
  extractedText?: string;
}

export class PDFAnalyzer {
  async extractInvoiceInfo(filePath: string): Promise<ExtractedInvoiceData> {
    try {
      console.log("Starting PDF analysis for:", filePath);

      // Use ImageMagick directly to convert PDF to PNG
      const outputPath = `./temp/page-${Date.now()}.png`;
      
      let base64Image: string;
      try {
        // Use ImageMagick convert command directly
        const command = `convert "${filePath}[0]" -density 150 -quality 100 "${outputPath}"`;
        console.log("Running ImageMagick command:", command);
        
        await execAsync(command);
        
        // Check if file was created
        if (!fs.existsSync(outputPath)) {
          console.error("ImageMagick conversion failed - output file not created");
          return {
            isExtracted: false,
            extractedText: "PDFの画像変換に失敗しました（ファイルが作成されませんでした）。",
          };
        }
        
        // Read the generated PNG file and convert to base64
        const imageBuffer = fs.readFileSync(outputPath);
        base64Image = imageBuffer.toString('base64');
        
        console.log("PDF converted to image successfully, base64 length:", base64Image.length);
        
        // Clean up temporary file
        fs.unlinkSync(outputPath);
        
        if (base64Image.length === 0) {
          console.error("Base64 conversion resulted in empty string");
          return {
            isExtracted: false,
            extractedText: "PDFの画像変換に失敗しました（空のbase64）。",
          };
        }
        
      } catch (conversionError) {
        console.error("PDF conversion failed:", conversionError);
        return {
          isExtracted: false,
          extractedText: `PDFの画像変換に失敗しました: ${conversionError instanceof Error ? conversionError.message : "Unknown error"}`,
        };
      }

      // Use OpenAI Vision to analyze the PDF image
      const response = await openai.chat.completions.create({
        model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
        messages: [
          {
            role: "system",
            content: `あなたは請求書の情報を抽出する専門家です。
            画像から日本語の請求書情報を読み取り、以下の情報を抽出してください：
            - 請求書番号（請求書No、Invoice No、請求番号など）
            - 請求元（請求を行う会社名、発行者、請求者、送付者など。請求先ではありません）
            - 請求日（請求書作成日、発行日、日付など）
            - 請求金額（合計金額、税込み金額、小計など）
            
            重要：companyNameは「請求を行う会社」を抽出してください。「請求される会社（宛先）」ではありません。
            通常、請求書の上部や左上に記載されている発行元の会社名を抽出してください。
            
            JSONフォーマットで回答してください。情報が見つからない場合はnullを返してください。
            例：{"invoiceNumber": "INV-2024-001", "companyName": "株式会社請求元", "invoiceDate": "2024-01-15", "totalAmount": "108,000円"}`,
          },
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "この請求書画像から情報を抽出してください："
              },
              {
                type: "image_url",
                image_url: {
                  url: `data:image/png;base64,${base64Image}`
                }
              }
            ],
          },
        ],
        response_format: { type: "json_object" },
        max_tokens: 1000,
      });

      const result = JSON.parse(response.choices[0].message.content || "{}");
      console.log("OpenAI Vision extraction result:", result);
      
      return {
        invoiceNumber: result.invoiceNumber || null,
        companyName: result.companyName || null,
        invoiceDate: result.invoiceDate || null,
        totalAmount: result.totalAmount || null,
        isExtracted: true,
        extractedText: `画像解析により抽出: ${JSON.stringify(result, null, 2)}`,
      };
    } catch (error) {
      console.error("PDF analysis error:", error);
      return {
        isExtracted: false,
        extractedText: `エラーが発生しました: ${error instanceof Error ? error.message : "Unknown error"}`,
      };
    }
  }
}

export const pdfAnalyzer = new PDFAnalyzer();