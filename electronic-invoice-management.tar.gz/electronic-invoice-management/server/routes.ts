import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertInvoiceDocumentSchema, searchInvoiceDocumentSchema } from "@shared/schema";
import { pdfAnalyzer } from "./pdf-analyzer";
import multer from "multer";
import path from "path";
import { z } from "zod";

// Extend Request type to include file property
interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Upload invoice document
  app.post("/api/documents", upload.single('file'), async (req: MulterRequest, res) => {
    try {
      console.log("Upload request received");
      console.log("File:", {
        fieldname: req.file?.fieldname,
        originalname: req.file?.originalname ? Buffer.from(req.file.originalname, 'latin1').toString('utf8') : undefined,
        encoding: req.file?.encoding,
        mimetype: req.file?.mimetype,
        size: req.file?.size,
      });
      console.log("Body:", req.body);
      
      if (!req.file) {
        return res.status(400).json({ message: "PDFファイルが必要です" });
      }

      const { invoiceNumber, companyName, invoiceDate } = req.body;

      // Fix filename encoding for Japanese characters
      let correctFilename = req.file.originalname;
      try {
        // Try to detect if the filename is encoded incorrectly
        if (correctFilename.includes('�') || /[^\x00-\x7F]/.test(correctFilename)) {
          // Attempt to fix encoding
          correctFilename = Buffer.from(correctFilename, 'latin1').toString('utf8');
        }
      } catch (error) {
        console.error('Filename encoding fix failed:', error);
        correctFilename = req.file.originalname;
      }
      
      // Save file to filesystem
      const filePath = await storage.saveFile(req.file.buffer, correctFilename);
      
      // Generate hash value for tamper prevention
      const hashValue = await storage.generateHashValue(filePath);

      // Extract invoice information from PDF
      const extractedInfo = await pdfAnalyzer.extractInvoiceInfo(filePath);
      
      // Use extracted data if available, otherwise use manual input
      const finalInvoiceNumber = invoiceNumber || extractedInfo.invoiceNumber || null;
      const finalCompanyName = companyName || extractedInfo.companyName || null;
      const finalInvoiceDate = invoiceDate || extractedInfo.invoiceDate || null;

      // Create document record
      const documentData = {
        filename: path.basename(filePath),
        originalName: correctFilename,
        invoiceNumber: finalInvoiceNumber,
        companyName: finalCompanyName,
        invoiceDate: finalInvoiceDate,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        filePath,
        hashValue,
        isCompliant: true,
        metadata: JSON.stringify({
          uploadedBy: "system",
          originalFilename: correctFilename,
          processingTimestamp: new Date().toISOString(),
          extractedInfo: extractedInfo,
          manuallyEntered: {
            invoiceNumber: !!invoiceNumber,
            companyName: !!companyName,
            invoiceDate: !!invoiceDate
          }
        })
      };

      const document = await storage.createInvoiceDocument(documentData);
      
      res.json({
        message: "ファイルが正常にアップロードされました",
        document,
        extractedInfo: extractedInfo.isExtracted ? {
          invoiceNumber: extractedInfo.invoiceNumber,
          companyName: extractedInfo.companyName,
          invoiceDate: extractedInfo.invoiceDate,
          totalAmount: extractedInfo.totalAmount,
          isAutoExtracted: true
        } : {
          message: "PDFからの自動抽出に失敗しました。手動で入力してください。",
          isAutoExtracted: false
        }
      });
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ 
        message: "ファイルアップロードに失敗しました",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get all documents
  app.get("/api/documents", async (req, res) => {
    try {
      const documents = await storage.getAllInvoiceDocuments();
      
      // Ensure proper UTF-8 encoding for Japanese text
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.json(documents);
    } catch (error) {
      console.error("Get documents error:", error);
      res.status(500).json({ message: "文書の取得に失敗しました" });
    }
  });

  // Get unique company names for dropdown
  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await storage.getUniqueCompanyNames();
      res.json(companies);
    } catch (error) {
      console.error("Get companies error:", error);
      res.status(500).json({ message: "会社名の取得に失敗しました" });
    }
  });

  // Search documents
  app.get("/api/documents/search", async (req, res) => {
    try {
      const searchParams = {
        invoiceNumber: req.query.invoiceNumber as string,
        companyName: req.query.companyName as string,
        invoiceDate: req.query.invoiceDate as string,
        complianceStatus: req.query.complianceStatus as string,
        sortBy: req.query.sortBy as string,
        sortOrder: req.query.sortOrder as "asc" | "desc",
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 10,
      };

      const result = await storage.searchInvoiceDocuments(searchParams);
      res.json(result);
    } catch (error) {
      console.error("Search error:", error);
      res.status(500).json({ message: "検索に失敗しました" });
    }
  });

  // Get specific document
  app.get("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      res.json(document);
    } catch (error) {
      console.error("Get document error:", error);
      res.status(500).json({ message: "文書の取得に失敗しました" });
    }
  });

  // Preview document (for PDF preview in iframe)
  app.get("/api/documents/:id/preview", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      const fileBuffer = await storage.getFile(document.filePath);
      
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', 'inline');
      res.send(fileBuffer);
    } catch (error) {
      console.error("Preview error:", error);
      res.status(500).json({ message: "ファイルプレビューに失敗しました" });
    }
  });

  // Download document file
  app.get("/api/documents/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      const fileBuffer = await storage.getFile(document.filePath);
      
      // Encode filename for Japanese characters
      const encodedFilename = encodeURIComponent(document.originalName);
      
      res.setHeader('Content-Type', document.mimeType);
      res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodedFilename}`);
      res.setHeader('Content-Length', fileBuffer.length.toString());
      res.send(fileBuffer);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "ファイルのダウンロードに失敗しました" });
    }
  });

  // Update document classification
  app.put("/api/documents/:id/classify", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { classification } = req.body;
      
      const document = await storage.getInvoiceDocument(id);
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }
      
      // Update metadata with classification
      const currentMetadata = document.metadata ? JSON.parse(document.metadata) : {};
      const updatedMetadata = {
        ...currentMetadata,
        classification,
        classificationUpdatedAt: new Date().toISOString()
      };
      
      const updatedDocument = await storage.updateInvoiceDocument(id, {
        metadata: JSON.stringify(updatedMetadata)
      });
      
      res.json({ message: "分類が更新されました", document: updatedDocument });
    } catch (error) {
      console.error("Classification error:", error);
      res.status(500).json({ message: "分類の更新に失敗しました" });
    }
  });

  // Generate audit report
  app.get("/api/documents/:id/audit", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      // Generate current hash to compare with stored hash
      const currentHash = await storage.generateHashValue(document.filePath);
      const integrityValid = currentHash === document.hashValue;
      
      const auditReport = {
        documentId: document.id,
        filename: document.originalName,
        invoiceNumber: document.invoiceNumber || "未設定",
        companyName: document.companyName || "未設定",
        uploadTimestamp: document.uploadedAt,
        originalHash: document.hashValue,
        currentHash: currentHash,
        integrityValid: integrityValid,
        complianceStatus: document.isCompliant ? "準拠" : "要確認",
        generatedAt: new Date().toISOString(),
        legalRequirements: {
          timestampCompliance: true, // タイムスタンプ付与済み
          tamperPrevention: integrityValid, // ハッシュ値による改ざん検証
          metadataRetention: !!document.metadata, // メタデータ保持
          electronicPreservation: true // 電子保存実装済み
        }
      };
      
      res.json(auditReport);
    } catch (error) {
      console.error("Audit report error:", error);
      res.status(500).json({ message: "監査証跡の生成に失敗しました" });
    }
  });

  // Update document metadata
  app.patch("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const document = await storage.updateInvoiceDocument(id, updates);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      res.json(document);
    } catch (error) {
      console.error("Update error:", error);
      res.status(500).json({ message: "文書の更新に失敗しました" });
    }
  });

  // Delete document
  app.delete("/api/documents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      // Delete the document from storage
      const success = await storage.deleteInvoiceDocument(id);
      
      if (success) {
        res.json({ message: "文書が削除されました" });
      } else {
        res.status(500).json({ message: "文書の削除に失敗しました" });
      }
    } catch (error) {
      console.error("Delete error:", error);
      res.status(500).json({ message: "文書の削除に失敗しました" });
    }
  });

  // Generate audit report
  app.get("/api/documents/:id/audit", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const document = await storage.getInvoiceDocument(id);
      
      if (!document) {
        return res.status(404).json({ message: "文書が見つかりません" });
      }

      // Generate current hash for verification
      const currentHash = await storage.generateHashValue(document.filePath);
      const isIntegrityValid = currentHash === document.hashValue;

      const auditReport = {
        documentId: document.id,
        filename: document.originalName,
        invoiceNumber: document.invoiceNumber,
        companyName: document.companyName,
        uploadTimestamp: document.uploadedAt,
        originalHash: document.hashValue,
        currentHash,
        integrityValid: isIntegrityValid,
        complianceStatus: document.isCompliant && isIntegrityValid ? "準拠" : "要確認",
        generatedAt: new Date().toISOString(),
        legalRequirements: {
          timestampCompliance: true,
          tamperPrevention: isIntegrityValid,
          metadataRetention: true,
          electronicPreservation: true
        }
      };

      res.json(auditReport);
    } catch (error) {
      console.error("Audit report error:", error);
      res.status(500).json({ message: "監査レポートの生成に失敗しました" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
