import { invoiceDocuments, type InvoiceDocument, type InsertInvoiceDocument } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import crypto from "crypto";
import fs from "fs";
import path from "path";

export interface IStorage {
  createInvoiceDocument(document: InsertInvoiceDocument): Promise<InvoiceDocument>;
  getInvoiceDocument(id: number): Promise<InvoiceDocument | undefined>;
  getAllInvoiceDocuments(): Promise<InvoiceDocument[]>;
  getUniqueCompanyNames(): Promise<string[]>;
  searchInvoiceDocuments(filters: {
    invoiceNumber?: string;
    companyName?: string;
    invoiceDate?: string;
    complianceStatus?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    page?: number;
    limit?: number;
  }): Promise<{ documents: InvoiceDocument[]; total: number }>;
  updateInvoiceDocument(id: number, updates: Partial<InvoiceDocument>): Promise<InvoiceDocument | undefined>;
  deleteInvoiceDocument(id: number): Promise<boolean>;
  generateHashValue(filePath: string): Promise<string>;
  saveFile(buffer: Buffer, filename: string): Promise<string>;
  getFile(filePath: string): Promise<Buffer>;
}

export class DatabaseStorage implements IStorage {
  private uploadsDir: string;

  constructor() {
    // Use server path if specified in environment, otherwise use local uploads
    const serverUploadDir = process.env.UPLOAD_DIR;
    if (serverUploadDir && fs.existsSync(path.dirname(serverUploadDir))) {
      this.uploadsDir = serverUploadDir;
    } else {
      this.uploadsDir = path.join(process.cwd(), "uploads");
    }
    
    // Create uploads directory if it doesn't exist
    if (!fs.existsSync(this.uploadsDir)) {
      fs.mkdirSync(this.uploadsDir, { recursive: true });
    }
    
    console.log(`📁 Upload directory: ${this.uploadsDir}`);
  }

  async createInvoiceDocument(insertDocument: InsertInvoiceDocument): Promise<InvoiceDocument> {
    const [document] = await db
      .insert(invoiceDocuments)
      .values({
        filename: insertDocument.filename,
        originalName: insertDocument.originalName,
        invoiceNumber: insertDocument.invoiceNumber || null,
        companyName: insertDocument.companyName || null,
        invoiceDate: insertDocument.invoiceDate || null,
        fileSize: insertDocument.fileSize,
        mimeType: insertDocument.mimeType,
        filePath: insertDocument.filePath,
        hashValue: insertDocument.hashValue,
        isCompliant: insertDocument.isCompliant || true,
        metadata: insertDocument.metadata || null,
      })
      .returning();
    return document;
  }

  async getInvoiceDocument(id: number): Promise<InvoiceDocument | undefined> {
    const [document] = await db.select().from(invoiceDocuments).where(eq(invoiceDocuments.id, id));
    return document || undefined;
  }

  async getAllInvoiceDocuments(): Promise<InvoiceDocument[]> {
    const documents = await db.select().from(invoiceDocuments);
    
    // Fix any encoding issues in the existing data
    const fixedDocuments = documents.map(doc => ({
      ...doc,
      originalName: doc.originalName ? this.fixEncoding(doc.originalName) : doc.originalName,
      companyName: doc.companyName ? this.fixEncoding(doc.companyName) : doc.companyName,
      invoiceNumber: doc.invoiceNumber ? this.fixEncoding(doc.invoiceNumber) : doc.invoiceNumber,
    }));
    
    return fixedDocuments.sort((a, b) => 
      new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async getUniqueCompanyNames(): Promise<string[]> {
    const documents = await db.select({
      companyName: invoiceDocuments.companyName
    }).from(invoiceDocuments);
    
    // Extract unique company names, filter out nulls and fix encoding
    const uniqueNames = Array.from(new Set(
      documents
        .map(doc => doc.companyName)
        .filter(name => name !== null && name !== undefined && name.trim() !== '')
        .map(name => this.fixEncoding(name!))
    ));
    
    return uniqueNames.sort();
  }

  private fixEncoding(str: string): string {
    try {
      // Try to detect and fix encoding issues
      if (str.includes('�') || str.includes('?')) {
        // String is likely corrupted, try to fix it
        const bytes = Buffer.from(str, 'latin1');
        const utf8String = bytes.toString('utf8');
        return utf8String;
      }
      return str;
    } catch (error) {
      console.error('Encoding fix failed:', error);
      return str;
    }
  }

  async searchInvoiceDocuments(filters: {
    invoiceNumber?: string;
    companyName?: string;
    invoiceDate?: string;
    complianceStatus?: string;
    sortBy?: string;
    sortOrder?: "asc" | "desc";
    page?: number;
    limit?: number;
  }): Promise<{ documents: InvoiceDocument[]; total: number }> {
    let query = db.select().from(invoiceDocuments);

    // For now, we'll fetch all documents and filter in memory
    // In production, you'd want to use SQL WHERE clauses
    const allDocuments = await query;
    
    let filteredDocuments = allDocuments;

    // Apply filters
    if (filters.invoiceNumber) {
      filteredDocuments = filteredDocuments.filter(doc => 
        doc.invoiceNumber?.toLowerCase().includes(filters.invoiceNumber!.toLowerCase())
      );
    }

    if (filters.companyName) {
      filteredDocuments = filteredDocuments.filter(doc => 
        doc.companyName?.toLowerCase().includes(filters.companyName!.toLowerCase())
      );
    }

    if (filters.invoiceDate) {
      filteredDocuments = filteredDocuments.filter(doc => 
        doc.invoiceDate?.includes(filters.invoiceDate!)
      );
    }

    if (filters.complianceStatus) {
      if (filters.complianceStatus === "compliant") {
        filteredDocuments = filteredDocuments.filter(doc => doc.isCompliant);
      } else if (filters.complianceStatus === "non-compliant") {
        filteredDocuments = filteredDocuments.filter(doc => !doc.isCompliant);
      }
    }

    // Sort documents
    const sortBy = filters.sortBy || "uploadedAt";
    const sortOrder = filters.sortOrder || "desc";
    
    filteredDocuments.sort((a, b) => {
      let aVal: any = a[sortBy as keyof InvoiceDocument];
      let bVal: any = b[sortBy as keyof InvoiceDocument];
      
      if (sortBy === "uploadedAt") {
        aVal = new Date(aVal).getTime();
        bVal = new Date(bVal).getTime();
      }
      
      if (aVal === null || aVal === undefined) aVal = "";
      if (bVal === null || bVal === undefined) bVal = "";
      
      if (sortOrder === "asc") {
        return aVal < bVal ? -1 : aVal > bVal ? 1 : 0;
      } else {
        return aVal > bVal ? -1 : aVal < bVal ? 1 : 0;
      }
    });

    const total = filteredDocuments.length;
    const page = filters.page || 1;
    const limit = filters.limit || 10;
    const skip = (page - 1) * limit;

    const documents = filteredDocuments.slice(skip, skip + limit);

    return { documents, total };
  }

  async updateInvoiceDocument(id: number, updates: Partial<InvoiceDocument>): Promise<InvoiceDocument | undefined> {
    const [document] = await db
      .update(invoiceDocuments)
      .set(updates)
      .where(eq(invoiceDocuments.id, id))
      .returning();
    return document || undefined;
  }

  async deleteInvoiceDocument(id: number): Promise<boolean> {
    const document = await this.getInvoiceDocument(id);
    if (!document) return false;

    // Delete file from filesystem
    try {
      if (fs.existsSync(document.filePath)) {
        fs.unlinkSync(document.filePath);
      }
    } catch (error) {
      console.error("Error deleting file:", error);
    }

    const result = await db.delete(invoiceDocuments).where(eq(invoiceDocuments.id, id));
    return (result.rowCount || 0) > 0;
  }

  async generateHashValue(filePath: string): Promise<string> {
    const buffer = await fs.promises.readFile(filePath);
    return crypto.createHash('sha256').update(buffer).digest('hex');
  }

  async saveFile(buffer: Buffer, filename: string): Promise<string> {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const safeFilename = `${timestamp}_${filename}`;
    const filePath = path.join(this.uploadsDir, safeFilename);
    
    await fs.promises.writeFile(filePath, buffer);
    return filePath;
  }

  async getFile(filePath: string): Promise<Buffer> {
    return fs.promises.readFile(filePath);
  }
}

export const storage = new DatabaseStorage();
