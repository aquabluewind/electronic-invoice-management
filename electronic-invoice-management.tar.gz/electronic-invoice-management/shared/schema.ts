import { pgTable, text, serial, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const invoiceDocuments = pgTable("invoice_documents", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  invoiceNumber: text("invoice_number"),
  companyName: text("company_name"),
  invoiceDate: text("invoice_date"),
  fileSize: integer("file_size").notNull(),
  mimeType: text("mime_type").notNull(),
  filePath: text("file_path").notNull(),
  hashValue: text("hash_value").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  isCompliant: boolean("is_compliant").default(true).notNull(),
  metadata: text("metadata"), // JSON string for additional metadata
  uploadedAt: timestamp("uploaded_at").defaultNow().notNull(),
});

export const insertInvoiceDocumentSchema = createInsertSchema(invoiceDocuments).omit({
  id: true,
  timestamp: true,
  uploadedAt: true,
});

export const updateInvoiceDocumentSchema = insertInvoiceDocumentSchema.partial();

export const searchInvoiceDocumentSchema = z.object({
  invoiceNumber: z.string().optional(),
  companyName: z.string().optional(),
  invoiceDate: z.string().optional(),
  page: z.number().optional().default(1),
  limit: z.number().optional().default(10),
});

export type InvoiceDocument = typeof invoiceDocuments.$inferSelect;
export type InsertInvoiceDocument = z.infer<typeof insertInvoiceDocumentSchema>;
export type UpdateInvoiceDocument = z.infer<typeof updateInvoiceDocumentSchema>;
export type SearchInvoiceDocument = z.infer<typeof searchInvoiceDocumentSchema>;
